import ReactLoading from 'react-loading';
import React, { useState, useRef, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTimes, faAngleRight } from '@fortawesome/free-solid-svg-icons';
import { Button, Image } from 'react-bootstrap';
import { Link, useLocation, useNavigate } from 'react-router-dom';

import BookList from '../../components/search/book-list';
import Footer from '../../components/footer';
import BookResponsiveNav from '../../components/nav/BookResponsiveNav';
import LoginModal from '../../components/modal/login';
import { getRequest, postRequest } from '../../services/api';
import { apiUrlList } from '../../services/api-url-list';

import './styles.css';

const PAGE_LIMIT = 10;

function Search() {
  const location = useLocation();
  const navigate = useNavigate();

  const [showModal, setShowModal] = useState(false);
  const [search, setSearch] = useState(location.state.search);
  const [books, setBooks] = useState([]);
  const [offset, setOffset] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [recentlyViewedBooks, setRecentlyViewedBooks] = useState(
    JSON.parse(localStorage.getItem('viewedBooks'), '[]')
  );
  const [currentUser, setCurrentUser] = useState(null);
  const [showLoggedInUserAction, setShowLoggedInUserAction] = useState(false);
  const [showSideSmall, setShowSideSmall] = useState(false);

  const handleShow = () => setShowModal(true);

  useEffect(() => {
    window.scrollTo(0, 0);

    getRequest(apiUrlList.currentUser, {}, {}, { withCredentials: true }).then(
      (response) => {
        setCurrentUser(response.data);
      }
    );
  }, []);

  useEffect(() => {
    setIsLoading(true);

    getRequest(
      apiUrlList.bookList,
      {},
      { search: location.state.search, offset: 0, limit: PAGE_LIMIT }
    )
      .then((response) => {
        setBooks(response.data.results);
        setIsLoading(false);
      })
      .catch(() => {});
  }, [location.state.search]);

  useEffect(() => {
    getRequest(
      apiUrlList.bookList,
      {},
      { search: location.state.search, offset, limit: PAGE_LIMIT }
    )
      .then((response) => {
        setBooks([...books, ...response.data.results]);
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [offset]);

  function onSubmit(e) {
    e.preventDefault();

    if (search !== '') {
      navigate('/search', {
        state: { search },
      });
    }
  }

  const ref = useRef();
  useOnClickOutside(ref, () => setShowModal(false));

  function useOnClickOutside(ref, handler) {
    useEffect(() => {
      const listener = (event) => {
        if (!ref.current || ref.current.contains(event.target)) {
          return;
        }
        handler(event);
      };
      document.addEventListener('mousedown', listener);
      document.addEventListener('touchstart', listener);
      return () => {
        document.removeEventListener('mousedown', listener);
        document.removeEventListener('touchstart', listener);
      };
    }, [ref, handler]);
  }

  function handleDelete(book) {
    const results = recentlyViewedBooks.filter(
      (recentBook) => recentBook.isbn13 !== book.isbn13
    );

    setRecentlyViewedBooks(results);
    localStorage.setItem('viewedBooks', JSON.stringify(results));
  }

  if (!location.state.search) {
    return null;
  }

  return (
    <>
      <div className="main-body">
        <div className="item-main">
          <div className="item-main-row">
            <div className="mob-menu">
              <div className="header-row">
                <Link to="/" className="sm-logo">
                  <Image
                    src={require('../../img/mobile-logo.png')}
                    className="log-pic img-fluid"
                    alt=".."
                  />
                </Link>
                <div className="dropdown">
                  <button
                    id="first"
                    type="button"
                    className="tg-btn"
                    data-toggle="dropdown"
                    onClick={() => setShowSideSmall(true)}
                  />
                  <div
                    id="mySide"
                    className="sidebar2-"
                    style={{ display: showSideSmall ? 'block' : 'none' }}
                  >
                    <div id="myBtn" className="new2">
                      <div className="texts">
                        <Link
                          to={{}}
                          state={{ search }}
                          id="closeBtn"
                          className="closeBtn2"
                          onClick={() => setShowSideSmall(false)}
                        >
                          <FontAwesomeIcon icon={faTimes} />
                        </Link>
                        <div className="left">
                          {currentUser ? (
                            <div className="login-register login-register2 login-register">
                              <div
                                className="dropdown"
                                onClick={() =>
                                  setShowLoggedInUserAction(
                                    !showLoggedInUserAction
                                  )
                                }
                              >
                                <Link
                                  to={{}}
                                  state={{ search }}
                                  className={
                                    !showLoggedInUserAction
                                      ? 'dropButton anti-btn dropdown-toggle'
                                      : 'dropButton anti-btn dropdown-toggle rotate'
                                  }
                                >
                                  {`Welcome ${currentUser.firstName}`}
                                </Link>
                              </div>

                              <div
                                className="sign-out-btn-drop"
                                style={{
                                  display: showLoggedInUserAction
                                    ? 'block'
                                    : 'none',
                                }}
                              >
                                <Link
                                  to={{}}
                                  state={{ search }}
                                  onClick={() => {
                                    postRequest(
                                      apiUrlList.logout,
                                      {},
                                      {},
                                      {},
                                      { withCredentials: true }
                                    )
                                      .then(() => {
                                        setCurrentUser(null);
                                      })
                                      .catch(() => {});
                                  }}
                                >
                                  Sign Out
                                </Link>
                                <Link
                                  state={{ search }}
                                  to={{}}
                                  onClick={() => {
                                    postRequest(
                                      apiUrlList.unRegister,
                                      {},
                                      {},
                                      {},
                                      { withCredentials: true }
                                    )
                                      .then(() => {
                                        setCurrentUser(null);
                                      })
                                      .catch(() => {});
                                  }}
                                >
                                  Unregister
                                </Link>
                              </div>
                            </div>
                          ) : (
                            <div
                              className="login-register"
                              onClick={handleShow}
                            >
                              <Link
                                to={{}}
                                state={{ search }}
                                style={{ color: '#fff' }}
                                data-toggle="modal"
                                data-target="#myModal2"
                              >
                                Hello! Sign In
                              </Link>
                            </div>
                          )}
                          <div className="sell-books">
                            <Link to="/" state="/sell">
                              Sell TextBooks
                            </Link>
                          </div>
                          <div className="sell-books sell-books2">
                            <Link to="/recently-viewed" className="item">
                              Recently Viewed
                            </Link>
                          </div>
                          <div className="items">
                            <div className="searches">
                              <div className="search-box search-box2">
                                {recentlyViewedBooks?.map((book, index) => (
                                  <div
                                    key={index}
                                    style={{
                                      display: 'flex',
                                      color: '#a3a8b9',
                                      fontSize: '13px',
                                      fontFamily: 'inherit',
                                      backgroundImage:
                                        'linear-gradient(-270deg, rgb(63, 64, 87) 0%, rgb(32, 33, 37) 100%)',
                                    }}
                                  >
                                    <FontAwesomeIcon
                                      color="#a3a8b9"
                                      icon={faAngleRight}
                                      style={{
                                        marginTop: '3px',
                                        marginRight: '3px',
                                      }}
                                    />
                                    <p
                                      style={{ paddingLeft: '5px' }}
                                      onClick={() => {
                                        navigate(
                                          `/book-details/${book.isbn13}`,
                                          {
                                            replace: true,
                                          }
                                        );
                                        setShowSideSmall(false);
                                      }}
                                    >
                                      {book.title}
                                    </p>
                                    <FontAwesomeIcon
                                      onClick={() => handleDelete(book)}
                                      color="#a3a8b9"
                                      style={{
                                        cursor: 'pointer',
                                        marginTop: '2px',
                                        marginLeft: 'auto',
                                      }}
                                      icon={faTimes}
                                    />
                                  </div>
                                ))}
                              </div>
                              <div className="clear-box">
                                <Link
                                  to={{}}
                                  onClick={() => {
                                    localStorage.removeItem('viewedBooks');
                                    setRecentlyViewedBooks([]);
                                  }}
                                >
                                  Clear Searches
                                </Link>
                              </div>
                            </div>
                          </div>
                          {/* <div className="other-links">
                          <Link to="/university">University Pages</Link>
                        </div> */}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="px-0 top-block">
              <div className="left left2">
                <Link to="/" className="cnt-logo">
                  <Image
                    src={require('../../img/logo.png')}
                    className="img-fluid cnt-lgo"
                    alt="..."
                  />
                </Link>
                <div className="logo-block"></div>
                {currentUser ? (
                  <div className="login-register login-register2 login-register">
                    <div
                      className="dropdown"
                      onClick={() =>
                        setShowLoggedInUserAction(!showLoggedInUserAction)
                      }
                    >
                      <Link
                        to={{}}
                        state={{ search }}
                        className={
                          !showLoggedInUserAction
                            ? 'dropButton anti-btn dropdown-toggle'
                            : 'dropButton anti-btn dropdown-toggle rotate'
                        }
                      >
                        {`Welcome ${currentUser.firstName}`}
                      </Link>
                    </div>

                    <div
                      className="sign-out-btn-drop"
                      style={{
                        display: showLoggedInUserAction ? 'block' : 'none',
                      }}
                    >
                      <Link
                        to={{}}
                        state={{ search }}
                        onClick={() => {
                          postRequest(
                            apiUrlList.logout,
                            {},
                            {},
                            {},
                            { withCredentials: true }
                          )
                            .then(() => {
                              setCurrentUser(null);
                            })
                            .catch(() => {});
                        }}
                      >
                        Sign Out
                      </Link>
                      <Link
                        to={{}}
                        state={{ search }}
                        onClick={() => {
                          postRequest(
                            apiUrlList.unRegister,
                            {},
                            {},
                            {},
                            { withCredentials: true }
                          )
                            .then(() => {
                              setCurrentUser(null);
                            })
                            .catch(() => {});
                        }}
                      >
                        Unregister
                      </Link>
                    </div>
                  </div>
                ) : (
                  <div className="login-register" onClick={handleShow}>
                    <Link
                      to={{}}
                      state={{ search }}
                      style={{ color: '#fff' }}
                      data-toggle="modal"
                      data-target="#myModal2"
                    >
                      Hello! Sign In
                    </Link>
                  </div>
                )}
                <div className="sell-books">
                  <Link to="/" state="/sell">
                    Sell Textbooks
                  </Link>
                </div>
                <div className="sell-books sell-books2">
                  <Link to="/recently-viewed" className="item">
                    Recently Viewed
                  </Link>
                </div>
                <div className="items">
                  <div className="searches">
                    <div className="search-box search-box2">
                      {recentlyViewedBooks?.map((book, index) => (
                        <div
                          key={index}
                          style={{
                            display: 'flex',
                            color: '#a3a8b9',
                            fontSize: '13px',
                            fontFamily: 'inherit',
                            backgroundImage:
                              'linear-gradient(-270deg, rgb(63, 64, 87) 0%, rgb(32, 33, 37) 100%)',
                          }}
                        >
                          <FontAwesomeIcon
                            color="#a3a8b9"
                            icon={faAngleRight}
                            style={{ marginTop: '3px', marginRight: '3px' }}
                          />
                          <p
                            style={{ paddingLeft: '5px', cursor: 'pointer' }}
                            onClick={() => {
                              navigate(`/book-details/${book.isbn13}`, {
                                replace: true,
                              });
                            }}
                          >
                            {book.title}
                          </p>
                          <FontAwesomeIcon
                            onClick={() => handleDelete(book)}
                            color="#a3a8b9"
                            style={{
                              cursor: 'pointer',
                              marginTop: '2px',
                              marginLeft: 'auto',
                            }}
                            icon={faTimes}
                          />
                        </div>
                      ))}
                    </div>

                    <div className="clear-box">
                      <Link
                        to={{}}
                        onClick={() => {
                          localStorage.removeItem('viewedBooks');
                          setRecentlyViewedBooks([]);
                        }}
                      >
                        Clear Searches
                      </Link>
                    </div>
                  </div>
                </div>
                {/* <div className="other-links">
                  <Link to="/university">University Pages</Link>
                </div> */}
              </div>
              <div className="right">
                <div className="search-country-bar item-search">
                  <div className="search-bar">
                    <div className="search-box">
                      <form onSubmit={onSubmit}>
                        <input
                          type="text"
                          placeholder="Search for ISBN, Title or Author"
                          value={search}
                          onChange={(e) => setSearch(e.target.value)}
                        />
                        <Button type="submit">
                          <i className="far fa-search" />
                        </Button>
                      </form>
                    </div>
                  </div>
                  <BookResponsiveNav />
                </div>
                {isLoading ? (
                  <div
                    style={{
                      background: 'white',
                      textAlign: 'center',
                      display: 'flex',
                      justifyContent: 'center',
                      padding: '200px',
                      borderRadius: '40px 0px 0px 40px',
                    }}
                  >
                    <div>
                      <ReactLoading
                        color="#89CFF0"
                        type="spin"
                        height={'100px'}
                        width={'100px'}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="all-content-block">
                    <BookList books={books} setIsLoading={setIsLoading} />
                    <div style={{ textAlign: 'center' }}>
                      <button
                        className="view-more-button"
                        onClick={() => {
                          setOffset(offset + PAGE_LIMIT);
                        }}
                      >
                        View More
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />

      <LoginModal showModal={showModal} setShowModal={setShowModal} />
    </>
  );
}

export default Search;
