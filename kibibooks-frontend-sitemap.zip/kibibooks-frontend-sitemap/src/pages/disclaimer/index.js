import React, { useEffect } from 'react';

import Footer from '../../components/footer';
import SecondaryHeader from '../../components/header/secondary-header';

import './styles.css';

function Disclaimer() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const tjs = document.getElementsByTagName('script')[0];
    let js = tjs;
    js = document.createElement('script');
    js.id = 'termly-jssdk';
    js.src = 'https://app.termly.io/embed-policy.min.js';
    tjs.parentNode.insertBefore(js, tjs);
  }, []);

  return (
    <>
      <div id="top" className="main-body">
        <div className="fixedUp px-0">
          <SecondaryHeader />
        </div>
        <div className="disc-main">
          <div className="disc-main-row">
            <div
              name="termly-embed"
              data-id="da8e3ae0-4c46-4d92-a37a-df3be02c08c3"
              data-type="iframe"
              style={{ marginTop: '-35px' }}
            ></div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}

export default Disclaimer;
