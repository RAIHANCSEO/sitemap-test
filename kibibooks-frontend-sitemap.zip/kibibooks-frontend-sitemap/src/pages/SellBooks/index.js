import React from "react";
import NavigationBar from "../../components/Navbar/NavigationBar";
import ResBookList from "../../components/HomePage/ResBookList";
import { SellBooksData } from "../../data/Data";
import Footer from "../../components/footer";
function SellBooks() {
  return (
    <div>
      <div>
        <NavigationBar />
      </div>
      <div>{/* <BookList HomePageData={SellBooksData} /> */}</div>
      <div>
        <ResBookList HomePageData={SellBooksData} />
      </div>
      {/* <div>
        <AppDownload />
      </div> */}
      <div>
        <Footer />
      </div>
    </div>
  );
}

export default SellBooks;
