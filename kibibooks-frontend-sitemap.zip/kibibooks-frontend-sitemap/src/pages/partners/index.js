import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Row, Col, Button } from 'react-bootstrap';

import Footer from '../../components/footer';

import './styles.css';
import { postRequest } from '../../services/api';
import { apiUrlList } from '../../services/api-url-list';
import SecondaryHeader from '../../components/header/secondary-header';

function Partner() {
  const navigate = useNavigate();

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [website, setWebsite] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [socialMediaChannels, setSocialMediaChannels] = useState('');
  const [promoteMessage, setPromoteMessage] = useState('');
  const [statisticMessage, setStatisticMessage] = useState('');
  const [attachment, setAttachment] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  function onSubmit(e) {
    e.preventDefault();

    setIsLoading(true);

    const formData = new FormData();
    formData.append('firstName', firstName);
    formData.append('lastName', lastName);
    formData.append('businessName', businessName);
    formData.append('website', website);
    formData.append('email', email);
    formData.append('phone', phone);
    formData.append('promoteMessage', promoteMessage);
    formData.append('statisticMessage', statisticMessage);

    if (socialMediaChannels) {
      formData.append('socialMediaChannels', socialMediaChannels);
    }

    if (attachment) {
      formData.append('attachment', attachment);
    }

    postRequest(apiUrlList.sendPartnerMessage, {}, {}, formData, {
      headers: {
        'content-type': 'multipart/form-data',
      },
    })
      .then(() => {
        navigate('/');
        setIsLoading(false);
      })
      .catch(() => {
        setIsLoading(false);
      });
  }

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Container fluid className="px-0" style={{ overflowX: 'hidden' }}>
        <Row id="top" className="mx-0 main-body">
          <div className="fixedUp px-0">
            <SecondaryHeader title="Partners" />
          </div>
          <div className="cont-main">
            <Col className="cont-main-row">
              <h2 className="mob">Partners</h2>
              <Col className="cont-form">
                <p>
                  Join our affiliate marketing program and monetize the traffic
                  of your websites, blogs, or other channels you are using.
                  Share your links and get paid for every conversion!
                </p>
                <form onSubmit={onSubmit}>
                  <div className="form-flex">
                    <input
                      type="text"
                      className="input"
                      placeholder="First Name"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      required
                    />
                    <input
                      type="text"
                      className="input"
                      placeholder="Last Name"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      required
                    />
                  </div>
                  <div className="form-flex">
                    <input
                      type="text"
                      className="input"
                      placeholder="Business Name"
                      value={businessName}
                      onChange={(e) => setBusinessName(e.target.value)}
                      required
                    />
                    <input
                      type="text"
                      className="input"
                      placeholder="Website"
                      value={website}
                      onChange={(e) => setWebsite(e.target.value)}
                      required
                    />
                  </div>
                  <div className="form-flex">
                    <input
                      type="email"
                      className="input"
                      placeholder="Email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                    <input
                      type="text"
                      className="input"
                      placeholder="Phone Number"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      required
                    />
                  </div>
                  <input
                    type="text"
                    className="input"
                    placeholder="Social Media Channels"
                    value={socialMediaChannels}
                    onChange={(e) => setSocialMediaChannels(e.target.value)}
                  />
                  <input
                    type="text"
                    className="input"
                    placeholder="How do you plan to promote Books?"
                    value={promoteMessage}
                    onChange={(e) => setPromoteMessage(e.target.value)}
                    required
                  />
                  <textarea
                    className="textarea"
                    placeholder="Describe your statistics of your website"
                    value={statisticMessage}
                    onChange={(e) => setStatisticMessage(e.target.value)}
                    required
                  />
                  <input
                    disabled={true}
                    type="text"
                    className="input customInputBox"
                    placeholder="Attach a screenshot of google analytics or any other analytics of your website"
                  />

                  <div className="container__">
                    <Button className="image-button" variant="dark">
                      Select Image
                    </Button>

                    <div className="input__">
                      <input
                        name="input"
                        id="file__"
                        type="file"
                        onChange={(e) => {
                          setAttachment(e.target.files[0]);
                        }}
                      />
                    </div>
                  </div>

                  <button
                    disabled={isLoading}
                    className="submit-button"
                    type="submit"
                  >
                    Submit
                  </button>
                </form>
              </Col>
            </Col>
          </div>
        </Row>
      </Container>
      <Footer />
    </>
  );
}

export default Partner;
