import React, { useEffect } from 'react';
import { Container, Col, Row } from 'react-bootstrap';

import Footer from '../../components/footer';
import SecondaryHeader from '../../components/header/secondary-header';

import './styles.css';

function Terms() {
  useEffect(() => {
    window.scrollTo(0, 0);

    let js,
      tjs = document.getElementsByTagName('script')[0];
    js = document.createElement('script');
    js.id = 'termly-jssdk';
    js.src = 'https://app.termly.io/embed-policy.min.js';
    tjs.parentNode.insertBefore(js, tjs);
  }, []);

  return (
    <>
      <Container fluid className="px-0">
        {' '}
        <Row id="top" className="mx-0 main-body">
          <Col className="px-0 fixedUp">
            <SecondaryHeader title="" />
          </Col>

          <Col className="px-0 disc-main">
            <div className="disc-main-row">
              <div
                name="termly-embed"
                data-id="2aac5058-f18a-4c10-bb08-16c174ebd7ae"
                data-type="iframe"
                style={{ marginTop: '-35px' }}
              ></div>
            </div>
          </Col>
        </Row>
      </Container>
      <Footer />
    </>
  );
}

export default Terms;
