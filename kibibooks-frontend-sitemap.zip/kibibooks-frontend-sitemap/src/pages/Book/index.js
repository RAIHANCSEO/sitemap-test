import React, { useState, useEffect } from "react";
import { Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import BookCard from "../../components/Book/BookCard";
import BookTiles from "../../components/Book/BookTiles";
import UsedBookTiles from "../../components/Book/UsedBookTiles";
import DigitalBookTiles from "../../components/Book/DigitalBookTiles";
import RentalBookTile from "../../components/Book/RentalBookTile";
import DigitalRentalBookTile from "../../components/Book/DigitalRentalBookTile";
import StudyGuideTile from "../../components/Book/StudyGuideTile";
import SuggestedBookTile from "../../components/Book/SuggestedBookTile";
import Footer from "../../components/footer";
import RelatedBook from "../../components/Book/RelatedBook";
import { Image } from "react-bootstrap";
import SideBar from "../../components/nav/SideBar";

import BookResponsiveNav from "../../components/nav/BookResponsiveNav";
import "./Book.css";

function Book() {
  const [showDropDown, setShowDropDown] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <div className="main-body">
      <div fluid className="item-main">
        <div className="item-main-row">
          <div className="mob-menu">
            <div className="header-row">
              <Link className="sm-logo" to="/">
                <Image
                  src={require("../../img/mobile-logo.png")}
                  className="log-pic img-fluid"
                  alt="..."
                />
              </Link>
              <SideBar />
            </div>
          </div>
          <div className="top-block">
            <div className="left left2">
              <Link to="/" className="cnt-logo">
                <Image
                  src={require("../../img/logo.png")}
                  className="img-fluid cnt-lgo"
                  alt="..."
                />
              </Link>
              <div className="logo-block"></div>
              <div className="login-register login-register2 login-register">
                <div
                  className="dropdown"
                  onClick={() => setShowDropDown(!showDropDown)}
                >
                  <Link
                    className={
                      !showDropDown
                        ? "dropButton anti-btn  dropdown-toggle"
                        : "dropButton anti-btn  dropdown-toggle rotate"
                    }
                    to={{}}
                  >
                    Welcome Anti
                  </Link>
                </div>

                <div
                  className="sign-out-btn-drop"
                  style={{ display: showDropDown ? "block" : "none" }}
                >
                  <Link to={{}}>Sign Out</Link>
                  <Link to={{}}>Unregister</Link>
                </div>
              </div>

              <div className="sell-books">
                <Link to="/" state="/sell">
                  Sell TextBooks
                </Link>
              </div>
              <div className="sell-books sell-books2">
                <Link to="/item" className="item">
                  Recently Viewed
                </Link>
              </div>
              <div className="items">
                <div className="searches">
                  <div className="search-box search-box2">
                    <h4 className="spn">0198708636</h4>
                  </div>
                  <div className="clear-box">
                    <Link to={{}}>Clear Searches</Link>
                  </div>
                </div>
              </div>
              {/* <div className="other-links">
                <Link to="/university">University Pages</Link>
              </div> */}
            </div>
            <div className="right">
              <div className="search-country-bar item-search">
                <div className="search-bar">
                  <div className="search-box">
                    <input
                      type="text"
                      placeholder="Search for ISBN, Title or Author"
                    />
                    <Button>
                      <i className="far fa-search" />
                    </Button>
                  </div>
                </div>

                <BookResponsiveNav />
              </div>
              <div className="all-content-block">
                <BookCard />

                <div className="details">
                  <BookTiles />
                  <UsedBookTiles />
                </div>

                <div className="details">
                  <DigitalBookTiles />
                  <RentalBookTile />
                </div>

                <div className="details">
                  <DigitalRentalBookTile />
                  <StudyGuideTile />
                </div>
                <SuggestedBookTile />
                <RelatedBook />
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
      {/* footer */}
    </div>
  );
}

export default Book;
