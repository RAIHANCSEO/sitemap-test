import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Row, Col } from 'react-bootstrap';

import Footer from '../../components/footer';
import SecondaryHeader from '../../components/header/secondary-header';

import { postRequest } from '../../services/api';
import { apiUrlList } from '../../services/api-url-list';

import './styles.css';

function Contact() {
  const navigate = useNavigate();

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  function onSubmit(event) {
    event.preventDefault();

    postRequest(
      apiUrlList.sendContactUsMessage,
      {},
      {},
      { firstName, lastName, email, message },
      {}
    )
      .then(() => {
        navigate('/');
      })
      .catch(() => {});
  }

  return (
    <>
      <Container fluid className="px-0">
        <Row id="top" className="main-body mx-0">
          <SecondaryHeader title="Contact Us" />
          <div className="cont-main">
            <Col className="cont-main-row">
              <h2 className="mob">Contact Us</h2>
              <div className="cont-form">
                <form onSubmit={onSubmit}>
                  <div className="form-flex">
                    <input
                      type="text"
                      className="input"
                      placeholder="First Name"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      required
                    />
                    <input
                      type="text"
                      className="input"
                      placeholder="Last Name"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      required
                    />
                  </div>
                  <input
                    type="email"
                    className="input"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                  <textarea
                    className="textarea"
                    placeholder="Tell us what this is about (500 characters)"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                  />
                  <button type="submit" className="submit-button">
                    Submit
                  </button>
                </form>
              </div>
            </Col>
          </div>
        </Row>
      </Container>

      <Footer />
    </>
  );
}
export default Contact;
