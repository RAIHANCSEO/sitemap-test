import ReactLoading from 'react-loading';
import React, { useState, useEffect } from 'react';
import { Col, Image } from 'react-bootstrap';
import { useParams } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faAngleRight,
  faSearch,
  faTimes,
} from '@fortawesome/free-solid-svg-icons';
import { Link, useNavigate } from 'react-router-dom';

import BookDetailsCard from '../../components/book-details/book-details-card';
import UsedBookPriceList from '../../components/book-details/used-book-price-list';
import NewBookPriceList from '../../components/book-details/new-book-price-list';
import DigitalBookPriceList from '../../components/book-details/digital-book-price-list';
import RentalBookPriceList from '../../components/book-details/rental-book-price-list';
import DigitalRentalBookPriceList from '../../components/book-details/digital-rental-book-price-list';
import StudyGuidePriceList from '../../components/book-details/study-guide-price-list';
import Footer from '../../components/footer';
import BookResponsiveNav from '../../components/nav/BookResponsiveNav';
import LoginModal from '../../components/modal/login';
import { getRequest, postRequest } from '../../services/api';
import { apiUrlList } from '../../services/api-url-list';

import '../Book/Book.css';

function BookDetails() {
  const history = useParams();
  const navigate = useNavigate();

  const { isbn13 } = history;

  const [showLoggedInUserAction, setShowLoggedInUserAction] = useState(false);
  const [bookDetails, setBookDetails] = useState(null);
  const [search, setSearch] = useState('');
  const [prices, setPrices] = useState({
    new: [],
    used: [],
    digital: [],
    rental: [],
    digitalRental: [],
    studyGuide: [],
    audioBook: [],
  });
  const [isLoading, setIsLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [ShowSideSmall, setShowSideSmall] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  const handleShow = () => setShowModal(true);

  useEffect(() => {
    window.scrollTo(0, 0);

    getRequest(apiUrlList.currentUser, {}, {}, { withCredentials: true }).then(
      (response) => {
        setCurrentUser(response.data);
      }
    );
  }, []);

  const [recentlyViewedBooks, setRecentlyViewedBooks] = useState(
    JSON.parse(localStorage.getItem('viewedBooks') || '[]')
  );

  function onSubmit(e) {
    e.preventDefault();

    if (search !== '') {
      navigate('/search', {
        state: { search },
      });
    }
  }

  function handleDelete(book) {
    const results = recentlyViewedBooks.filter(
      (recentBook) => recentBook.isbn13 !== book.isbn13
    );

    setRecentlyViewedBooks(results);
    localStorage.setItem('viewedBooks', JSON.stringify(results));
  }

  useEffect(() => {
    if (isbn13) {
      setIsLoading(true);

      getRequest(apiUrlList.bookDetails, { isbn13 })
        .then((response) => {
          const responseData = response.data;
          setBookDetails(responseData);

          const newBooks = responseData.prices
            .filter((price) => price.type === 'new')
            .sort((a, b) => a.price - b.price);
          const used = responseData.prices
            .filter((price) => price.type === 'used')
            .sort((a, b) => a.price - b.price);
          const rental = responseData.prices
            .filter((price) => price.type === 'rental')
            .sort((a, b) => a.price - b.price);
          const digital = responseData.prices
            .filter((price) => price.type === 'digital')
            .sort((a, b) => a.price - b.price);
          const digitalRental = responseData.prices
            .filter((price) => price.type === 'digitalRental')
            .sort((a, b) => a.price - b.price);
          const studyGuide = responseData.prices
            .filter((price) => price.type === 'studyGuide')
            .sort((a, b) => a.price - b.price);
          const audioBook = responseData.prices
            .filter((price) => price.type === 'audioBook')
            .sort((a, b) => a.price - b.price);

          let viewedBooks = JSON.parse(
            localStorage.getItem('viewedBooks') || '[]'
          );

          viewedBooks = viewedBooks.filter((book) => book.isbn13 !== isbn13);
          viewedBooks.unshift({
            isbn13,
            title: responseData.title,
            authors: `${responseData.authors.join(' and ')}`,
            image: responseData.image,
            bestPrices: [
              newBooks.length ? newBooks[0] : {},
              used.length ? used[0] : {},
              digital.length ? digital[0] : {},
              rental.length ? rental[0] : {},
              digitalRental.length ? digitalRental[0] : {},
              studyGuide.length ? studyGuide[0] : {},
            ].filter((value) => value !== 0),
          });

          while (viewedBooks.length > 25) {
            viewedBooks.pop();
          }

          localStorage.setItem('viewedBooks', JSON.stringify(viewedBooks));
          setRecentlyViewedBooks(viewedBooks);

          setPrices({
            new: newBooks,
            used,
            digital,
            digitalRental,
            rental,
            studyGuide,
            audioBook,
          });

          setIsLoading(false);
        })
        .catch(() => {});
    }
  }, [isbn13]);

  return (
    <div className="main-body ">
      <div className="item-main ">
        <div className="item-main-row ">
          <div className="mob-menu">
            <div className="header-row">
              <Link className="sm-logo" to="/">
                <Image
                  src={require('../../img/mobile-logo.png')}
                  className="log-pic img-fluid"
                  alt="..."
                />
              </Link>
              <div className="dropdown">
                <button
                  id="first"
                  type="button"
                  className="tg-btn"
                  data-toggle="dropdown"
                  onClick={() => setShowSideSmall(true)}
                />
                <div
                  id="mySide"
                  className="sidebar2-"
                  style={{ display: ShowSideSmall ? 'block' : 'none' }}
                >
                  <div id="myBtn" className="new2">
                    <div className="texts">
                      <Link
                        to={{}}
                        id="closeBtn"
                        className="closeBtn2"
                        onClick={() => setShowSideSmall(false)}
                      >
                        <FontAwesomeIcon icon={faTimes} />
                      </Link>
                      <div className="left">
                        {currentUser ? (
                          <div className="login-register login-register2 login-register">
                            <div
                              className="dropdown"
                              onClick={() =>
                                setShowLoggedInUserAction(
                                  !showLoggedInUserAction
                                )
                              }
                            >
                              <Link
                                to={{}}
                                className={
                                  !showLoggedInUserAction
                                    ? 'dropButton anti-btn dropdown-toggle'
                                    : 'dropButton anti-btn dropdown-toggle rotate'
                                }
                              >
                                {`Welcome ${currentUser.firstName}`}
                              </Link>
                            </div>

                            <div
                              className="sign-out-btn-drop"
                              style={{
                                display: showLoggedInUserAction
                                  ? 'block'
                                  : 'none',
                              }}
                            >
                              <Link
                                to={{}}
                                onClick={() => {
                                  postRequest(
                                    apiUrlList.logout,
                                    {},
                                    {},
                                    {},
                                    { withCredentials: true }
                                  )
                                    .then(() => {
                                      setCurrentUser(null);
                                    })
                                    .catch(() => {});
                                }}
                              >
                                Sign Out
                              </Link>
                              <Link
                                to={{}}
                                onClick={() => {
                                  postRequest(
                                    apiUrlList.unRegister,
                                    {},
                                    {},
                                    {},
                                    { withCredentials: true }
                                  )
                                    .then(() => {
                                      setCurrentUser(null);
                                    })
                                    .catch(() => {});
                                }}
                              >
                                Unregister
                              </Link>
                            </div>
                          </div>
                        ) : (
                          <div className="login-register" onClick={handleShow}>
                            <Link
                              to={{}}
                              style={{ color: '#fff' }}
                              data-toggle="modal"
                              data-target="#myModal2"
                            >
                              Hello! Sign In
                            </Link>
                          </div>
                        )}
                        <div className="sell-books">
                          <Link to="/" state="/sell">
                            Sell TextBooks
                          </Link>
                        </div>
                        <div className="sell-books sell-books2">
                          <Link to="/recently-viewed" className="item">
                            Recently Viewed
                          </Link>
                        </div>
                        <div className="items">
                          <div className="searches">
                            <div className="search-box search-box2">
                              {recentlyViewedBooks?.map((book, index) => (
                                <div
                                  key={index}
                                  style={{
                                    display: 'flex',
                                    color: '#a3a8b9',
                                    fontSize: '13px',
                                    fontFamily: 'inherit',
                                    backgroundImage:
                                      'linear-gradient(-270deg, rgb(63, 64, 87) 0%, rgb(32, 33, 37) 100%)',
                                  }}
                                >
                                  <FontAwesomeIcon
                                    color="#a3a8b9"
                                    icon={faAngleRight}
                                    style={{
                                      marginTop: '3px',
                                      marginRight: '3px',
                                    }}
                                  />
                                  <p
                                    style={{ paddingLeft: '5px' }}
                                    onClick={() => {
                                      navigate(`/book-details/${book.isbn13}`, {
                                        replace: true,
                                      });
                                      setShowSideSmall(false);
                                    }}
                                  >
                                    {book.title}
                                  </p>
                                  <FontAwesomeIcon
                                    onClick={() => handleDelete(book)}
                                    color="#a3a8b9"
                                    style={{
                                      cursor: 'pointer',
                                      marginTop: '2px',
                                      marginLeft: 'auto',
                                    }}
                                    icon={faTimes}
                                  />
                                </div>
                              ))}
                            </div>
                            <div className="clear-box">
                              <Link
                                to={{}}
                                onClick={() => {
                                  localStorage.removeItem('viewedBooks');
                                  setRecentlyViewedBooks([]);
                                }}
                              >
                                Clear Searches
                              </Link>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="top-block">
            <div className="left left2">
              <Link to="/" className="cnt-logo">
                <Image
                  src={require('../../img/logo.png')}
                  className="img-fluid cnt-lgo"
                  alt="..."
                />
              </Link>
              <div className="logo-block"></div>
              {currentUser ? (
                <div className="login-register login-register2 login-register">
                  <div
                    className="dropdown"
                    onClick={() =>
                      setShowLoggedInUserAction(!showLoggedInUserAction)
                    }
                  >
                    <Link
                      to={{}}
                      className={
                        !showLoggedInUserAction
                          ? 'dropButton anti-btn dropdown-toggle'
                          : 'dropButton anti-btn dropdown-toggle rotate'
                      }
                    >
                      {`Welcome ${currentUser.firstName}`}
                    </Link>
                  </div>

                  <div
                    className="sign-out-btn-drop"
                    style={{
                      display: showLoggedInUserAction ? 'block' : 'none',
                    }}
                  >
                    <Link
                      to={{}}
                      onClick={() => {
                        postRequest(
                          apiUrlList.logout,
                          {},
                          {},
                          {},
                          { withCredentials: true }
                        )
                          .then(() => {
                            setCurrentUser(null);
                          })
                          .catch(() => {});
                      }}
                    >
                      Sign Out
                    </Link>
                    <Link
                      to={{}}
                      onClick={() => {
                        postRequest(
                          apiUrlList.unRegister,
                          {},
                          {},
                          {},
                          { withCredentials: true }
                        )
                          .then(() => {
                            setCurrentUser(null);
                          })
                          .catch(() => {});
                      }}
                    >
                      Unregister
                    </Link>
                  </div>
                </div>
              ) : (
                <div className="login-register" onClick={handleShow}>
                  <Link
                    to={{}}
                    style={{ color: '#fff' }}
                    data-toggle="modal"
                    data-target="#myModal2"
                  >
                    Hello! Sign In
                  </Link>
                </div>
              )}
              <div className="sell-books">
                <Link to="/" state="/sell">
                  Sell TextBooks
                </Link>
              </div>
              <div className="sell-books sell-books2">
                <Link to="/recently-viewed" className="item">
                  Recently Viewed
                </Link>
              </div>
              <div className="items">
                <div className="searches">
                  <div className="search-box search-box2">
                    {recentlyViewedBooks.map((book, index) => (
                      <div
                        key={index}
                        style={{
                          display: 'flex',
                          color: '#a3a8b9',
                          fontSize: '13px',
                          fontFamily: 'inherit',
                          backgroundImage:
                            'linear-gradient(-270deg, rgb(63, 64, 87) 0%, rgb(32, 33, 37) 100%)',
                        }}
                      >
                        <FontAwesomeIcon
                          color="#a3a8b9"
                          icon={faAngleRight}
                          style={{ marginTop: '3px', marginRight: '3px' }}
                        />
                        <p
                          style={{ paddingLeft: '5px', cursor: 'pointer' }}
                          onClick={() => {
                            navigate(`/book-details/${book.isbn13}`, {
                              replace: true,
                            });
                          }}
                        >
                          {book.title}
                        </p>
                        <FontAwesomeIcon
                          onClick={() => handleDelete(book)}
                          color="#a3a8b9"
                          style={{
                            cursor: 'pointer',
                            marginTop: '2px',
                            marginLeft: 'auto',
                          }}
                          icon={faTimes}
                        />
                      </div>
                    ))}
                  </div>
                  <div className="clear-box">
                    <Link
                      to={{}}
                      onClick={() => {
                        localStorage.removeItem('viewedBooks');
                        setRecentlyViewedBooks([]);
                      }}
                    >
                      Clear Searches
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <Col className="right">
              <Col className="search-country-bar item-search">
                <div className="search-bar">
                  <div className="search-box">
                    <form onSubmit={onSubmit}>
                      <input
                        type="text"
                        placeholder="Search for ISBN, Title or Author"
                        onChange={(e) => {
                          setSearch(e.target.value);
                        }}
                      />
                      <button type="submit">
                        <FontAwesomeIcon icon={faSearch} />
                      </button>
                    </form>
                  </div>
                </div>
                <BookResponsiveNav />
              </Col>
              {isLoading ? (
                <div
                  style={{
                    background: 'white',
                    textAlign: 'center',
                    display: 'flex',
                    justifyContent: 'center',
                    padding: '200px',
                    borderRadius: '40px 0px 0px 40px',
                  }}
                >
                  <div>
                    <ReactLoading
                      color="#89CFF0"
                      type="spin"
                      height={'100px'}
                      width={'100px'}
                    />
                  </div>
                </div>
              ) : (
                <Col className="all-content-block">
                  <BookDetailsCard
                    bookDetails={bookDetails}
                    bestPrices={[
                      prices.new.length && prices.new[0],
                      prices.used.length && prices.used[0],
                      prices.digital.length && prices.digital[0],
                      prices.rental.length && prices.rental[0],
                      prices.digitalRental.length && prices.digitalRental[0],
                    ].filter((value) => value !== 0)}
                  />
                  <div className="details">
                    <NewBookPriceList prices={prices.new} />
                    <UsedBookPriceList prices={prices.used} />
                  </div>
                  <div className="details">
                    <DigitalBookPriceList prices={prices.digital} />
                    <RentalBookPriceList prices={prices.rental} />
                  </div>
                  <div className="details">
                    <DigitalRentalBookPriceList prices={prices.digitalRental} />
                    <StudyGuidePriceList
                      audioBookPrices={prices.audioBook}
                      studyGuidePrices={prices.studyGuide}
                    />
                  </div>
                  {/* <SuggestedBookTile />
                <RelatedBook /> */}
                </Col>
              )}
            </Col>
          </div>
        </div>
      </div>

      <LoginModal showModal={showModal} setShowModal={setShowModal} />

      <Footer />
    </div>
  );
}

export default BookDetails;
