import React, { useEffect } from 'react';
import Footer from '../../components/footer';
import { Container, Row, Col } from 'react-bootstrap';
import CustomAccordion from '../../components/accrodon';
import SecondaryHeader from '../../components/header/secondary-header';

import './styles.css';

const helpData = [
  {
    title: 'What is Kibidooks?',
    text: `Kibibooks is a convenient one-stop shop for students to find their academic books in the cheapest prices available. 
    Students can search by ISBN, Title, or Author to find the books they need for their classes, and Kibibooks compares textbooks prices among the largest and most trustworthy sellers.`,
  },
  {
    title: 'Which countries Kibibooks serve?',
    text: 'Kibibooks is currently available to all residents of the United States.',
  },
  {
    title: 'What is an ISBN number?',
    text: 'An ISBN (International Standard Book Number) is basically a book identifier used by publishers, booksellers, libraries, internet retailers, and other supply chain participants.',
  },
  {
    title: 'How can I opt out from emails?',
    text: `Anyone who has signed in using either their Facebook or Google usernames can opt out from emails. 
    Simply click on “Unregister” under your account name and you will be opted out.`,
  },
  {
    title: 'Who can use Kibibooks?',
    text: `Anybody 13 yrs and older can use Kibibooks. We believe Kibibooks is great for all students but we have to comply with rules and regulations. 
    Please, review our Terms & Conditions.`,
  },
  {
    title: 'How long has Kibibooks been around?',
    text: `Kibibooks was started in 2020 by students for students. Academia is hard enough without being expensive. 
    We are determined to find you the best prices for your educational materials.`,
  },
  {
    title: 'How do I search for books?',
    text: `Glad you asked! First, ask yourself if you want to buy, rent, or sell a book? 
    Our search engine will guide you through the process. 
    To buy a book, you can start by searching for either the ISBN, Title or Author of the book you are trying to buy. 
    Then, just hit search or enter!`,
  },
  {
    title: 'Does Kibibooks sell any books?',
    text: `Kibibooks does not sell any books or related materials.
    We only work with partners and our network.`,
  },
  {
    title: 'Does Kibibooks sell only academic books?',
    text: `Kibibooks does not only sell academic books. You can search for any and all books of your choice! 
    Kibibooks does all the hard work to find you a great price and show that to your with other good options.`,
  },
  {
    title: 'How can I provide feedback?',
    text: `We are always looking to improve our site and how we serve you.  Please let us know your thoughts by clicking on “Customer Reviews”.  
    We would love to hear from you!`,
  },
  {
    title: 'Should I buy a Used or New?',
    text: `There are great reasons for both!  A few reasons why it may be preferable to buy a used book are that used books are generally cheaper. Some 25% less or more! Also, used books are sometimes highlighted, a gift for the new owner because it maps the road to succeeding in the class. And, you can sell back a used book, possibly for the same value that you bought it.
    With new books, you’re guaranteed a product in great condition. Conversely, you are the first person who may highlight it and set your own path. The list goes on, but ultimately it is your choice.`,
  },
];

function Help() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Container fluid className="px-0" style={{ overflowX: 'hidden' }}>
        <Row id="top" className="main-body mx-0">
          <div className="fixedUp px-0">
            <SecondaryHeader title="Help & Support" />
          </div>

          <div className="disc-main">
            <Col className="disc-main-row">
              <h2 className="mob">Help &amp; Support</h2>
              <Col className="disc-main-text">
                <h6>
                  Our Help &amp; Support page could answer most of the questions
                  you have. If your question is not answerd in this section,
                  please, contact us. Frequently asked questions:
                </h6>
                <Col className="disc-main-flex">
                  <Col className="disc-main-left">
                    <CustomAccordion data={helpData} />
                  </Col>
                </Col>
              </Col>
            </Col>
          </div>
        </Row>
      </Container>

      <Footer />
    </>
  );
}

export default Help;
