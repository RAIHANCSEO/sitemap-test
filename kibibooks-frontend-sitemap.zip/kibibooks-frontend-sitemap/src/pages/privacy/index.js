import React, { useEffect } from 'react';
import { Container, Row } from 'react-bootstrap';

import SecondaryHeader from '../../components/header/secondary-header';
import Footer from '../../components/footer';

function Privacy() {
  useEffect(() => {
    window.scrollTo(0, 0);
    var js,
      tjs = document.getElementsByTagName('script')[0];
    js = document.createElement('script');
    js.id = 'termly-jssdk';
    js.src = 'https://app.termly.io/embed-policy.min.js';
    tjs.parentNode.insertBefore(js, tjs);
  }, []);

  return (
    <>
      <Container fluid className="px-0" style={{ overflowX: 'hidden' }}>
        <Row id="top" className="main-body mx-0">
          <div className="fixedUp px-0">
            <SecondaryHeader title="" />
          </div>
          <div className="disc-main">
            <div className="disc-main-row">
                <div
                  name="termly-embed"
                  data-id="e3d26f55-d690-4b00-8ec0-42bfcc794548"
                  data-type="iframe"
                  style={{ marginTop: '-35px' }}
                ></div>
            </div>
          </div>
        </Row>
      </Container>
      <Footer />
    </>
  );
}

export default Privacy;
