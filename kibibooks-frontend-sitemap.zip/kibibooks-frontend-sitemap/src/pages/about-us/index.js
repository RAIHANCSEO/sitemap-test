import React, { useState, useEffect } from 'react';
import { Container, Row, Col } from 'react-bootstrap';

import Footer from '../../components/footer';
import LoginModal from '../../components/modal/login';
import SecondaryHeader from '../../components/header/secondary-header';

import './styles.css';

function AboutUs() {
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Container fluid className="px-0" style={{ overflowX: 'hidden' }}>
        <Row id="top" className="main-body mx-0">
          <SecondaryHeader title="About Us" />

          <div className="about-main" style={{ padding: '60px 0px 0px 0px' }}>
            <Col className="about-main-row">
              <Col className="about-main-text">
                <h2 className="mob">About Us</h2>
                <p>
                  Hello, welcome to KibiBooks! We believe that knowledge is
                  power, and thus we are on a mission to help break down
                  barriers so that everyone can attain their pursuit of
                  knowledge.
                </p>
                <p>
                  We have all been students at some point. Aside from the
                  skyrocketing tuition fees, another barrier for students is the
                  rising cost of books. We have seen firsthand how the price of
                  books can be detrimental to a student's journey towards
                  attaining their goals.
                </p>
                <p>
                  We understand the reason why books are priced as such. After
                  all, the authors and the publishing company worked tirelessly
                  to develop a resource material that we could rely upon.
                  However, still, we thought we had to do something to break
                  down this proverbial “barrier” to education.
                </p>
                <p>
                  We cannot dictate the books' price, but we figured we could
                  redirect our efforts to find another solution.
                </p>
                <p>
                  On top of that, during the pandemic, access to libraries was
                  either restricted or limited. This proved to be another
                  hindrance to a student’s access to much-needed books and other
                  resource materials. Since buying their own set of books from
                  the university or local bookstore proved to be expensive, we
                  realized that we really had to do something.
                </p>
                <p>That’s the reason why we started KibiBooks.</p>
                <p>
                  KibiBooks is a platform where you can search for the books you
                  need. Be it textbooks you need for class or just about any
                  book. Our amazing team of developers found a way to scan the
                  internet to connect you with the seller that's offering the
                  most bang for your buck price for the said book.
                </p>
                <p>
                  While researching the best way we can do something about our
                  advocacy, we noticed that students and other learners spend
                  too much time scouring the web to look for the most affordable
                  price for the books they need. It’s fortunate if you only need
                  to spend a few minutes to find the book you need, but for some
                  books, as rare as they are, students spend hours just looking
                  for the most affordable one.
                </p>
                <p>
                  We all know that there is no better way to spend a student’s
                  time than for them to use it for studying. So through
                  KibiBooks, we are trying to revolutionize the way students and
                  other learners search for books by giving a platform that will
                  help them search for the best-priced book out there so that
                  they will have more time to do the more important things as
                  students.
                </p>
                <p>
                  KibiBooks is a platform built by students for students. We are
                  not the first ones to offer this kind of service, but we are
                  different because we know how students feel and what they
                  need.
                </p>
                <p>
                  We’ve made our platform easy to use and intuitive. If you take
                  a look at what we did with KibiBooks, you can immediately
                  notice that everything’s laid out to be straightforward. You
                  can quickly buy, rent, and even sell your book with just a few
                  clicks of a button. If you’re looking for a book, just type in
                  its ISBN on the search box and watch KibiBooks do its magic.
                </p>
                <p>Mission</p>
                <p>
                  Going back to our vision, we believe that knowledge brings
                  with it a certain degree of power. We do not agree that just
                  because you do not have the financial capacity, you are no
                  longer qualified to learn. No, not on our watch.
                </p>
                <p>
                  We aim to make things more accessible, starting with getting
                  your hands on the most affordable books out there.
                </p>
                <p className="last">
                  With KibiBooks, a student’s dream of having access to
                  affordable or cheap textbooks no longer stays a dream. We are
                  now here to help students save money and get better deals on
                  their books.
                </p>
              </Col>
            </Col>
          </div>
        </Row>
        <Footer />
      </Container>
      <LoginModal showModal={showModal} setShowModal={setShowModal} />
    </>
  );
}

export default AboutUs;
