// THIS IS THE SECOND PAGE (DOWNLOAD APP AD)

// import React from "react";
// import NavigationBar from "../../components/Navbar/NavigationBar";
// import BookList from "../../components/HomePage/bookList";
// import ResBookList from "../../components/HomePage/ResBookList";
// import { SellBooksData } from "../../data/Data";
// import AppDownload from "../../components//AppDownload";
// import Footer from "../../components/Footer";
// function LandingPage() {
//   return (
//     <>
//       <NavigationBar />
//       <BookList HomePageData={SellBooksData} />
//       <ResBookList HomePageData={SellBooksData} />
//       <AppDownload />
//       <Footer />
//     </>
//   );
// }

// export default LandingPage;
