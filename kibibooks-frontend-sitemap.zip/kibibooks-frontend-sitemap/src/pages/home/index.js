import React, { useEffect, useState } from 'react';
import ReactLoading from 'react-loading';

import BookList from '../../components/home/book-list';
import MobileBookList from '../../components/home/mobile-book-list';
import NavigationBar from '../../components/nav/nav-bar';
import Footer from '../../components/footer';
import { getRequest } from '../../services/api';
import { apiUrlList } from '../../services/api-url-list';

import './style.css';

function HomePage() {
  const [mostPuschasedBooks, setMostPurchasedBooks] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setIsLoading(true);

    getRequest(
      apiUrlList.bookList,
      {},
      {
        isbns: [
          '9780205309023',
          '9781319122843',
          '9780226823362',
          '9780717802418',
          '9781503379985',
          '9780357231500',
          '9780141439471',
          '9780140424386',
          '9780199213610',
          '9780201473513',
          '9780335235827',
          '9781770483095',
          '9780393933611',
          '9781613825440',
          '9781319107123',
          '9780679752554',
          '9781137289254',
          '9781317875321',
          '9780199689453',
          '9781506386706',
        ],
      }
    ).then((response) => {
      setIsLoading(false);
      setMostPurchasedBooks(response.data.results);
    });
  }, []);

  return (
    <>
      <NavigationBar />
      {isLoading ? (
        <div
          style={{
            height: '100%',
            width: '100%',
            background: 'white',
            textAlign: 'center',
            marginTop: '245px',
            display: 'flex',
            justifyContent: 'center',
            padding: '100px',
          }}
        >
          <div>
            <ReactLoading
              color="#89CFF0"
              type="spin"
              height={'100px'}
              width={'100px'}
            />
          </div>
        </div>
      ) : (
        <>
          <BookList books={mostPuschasedBooks} />
          <MobileBookList books={mostPuschasedBooks} />
        </>
      )}
      <Footer />
    </>
  );
}

export default HomePage;
