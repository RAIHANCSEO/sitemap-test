import React, { useState, useRef, useEffect } from 'react';

import { Modal, Container, Row, Col, Image, Button } from 'react-bootstrap';
import UniversityTiles from '../../components/University/UniversityTiles';
import Footer from '../../components/footer';
import SideBar from '../../components/Navbar/SideBar';
import {
  TilesR1,
  TilesR2,
  TilesR3,
  TilesR4,
  TilesR5,
  TilesR6,
  TilesR7,
  TilesR8,
  TilesR9,
} from '../../data/UniversityTilesData';
import './University.css';
import { Link, useLocation } from 'react-router-dom';
import BookResponsiveNav from '../../components/Navbar/BookResponsiveNav';
import LoginModal from '../../components/modal/login';
function University(props) {
  const [showModal, setShowModal] = useState(false);
  const handleClose = () => setShowModal(false);
  const handleShow = () => setShowModal(true);
  const [showTabs, setShowTabs] = useState(true);

  const { pathname } = useLocation();
  const handleShowTab = () => {
    setShowTabs(true);
  };
  const handleShowTabs = () => {
    setShowTabs(false);
  };
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const ref = useRef();
  useOnClickOutside(ref, () => setShowModal(false));

  function useOnClickOutside(ref, handler) {
    useEffect(() => {
      const listener = (event) => {
        if (!ref.current || ref.current.contains(event.target)) {
          return;
        }
        handler(event);
      };
      document.addEventListener('mousedown', listener);
      document.addEventListener('touchstart', listener);
      return () => {
        document.removeEventListener('mousedown', listener);
        document.removeEventListener('touchstart', listener);
      };
    }, [ref, handler]);
  }

  return (
    <>
      <Container fluid className="main-body px-0">
        <Row className="item-main mx-0">
          <Col className="item-main-row">
            <div className="mob-menu">
              <div className="header-row">
                <Link className="sm-logo" to="/">
                  <Image
                    src={require('../../img/mobile-logo.png')}
                    className="log-pic img-fluid"
                    alt="..."
                  />
                </Link>
                <SideBar />
              </div>
            </div>

            <Col className="top-block">
              <div className="left left2">
                <Link to="/" className="cnt-logo">
                  <Image
                    src={require('../../img/logo.png')}
                    className="img-fluid cnt-lgo"
                    alt="..."
                  />
                </Link>
                <div className="logo-block"></div>
                <div className="login-register" onClick={handleShow}>
                  <Link
                    to={{}}
                    style={{ color: '#fff' }}
                    data-toggle="modal"
                    data-target="#myModal2"
                  >
                    Hello! Sign In
                  </Link>
                </div>
                <div className="sell-books">
                  <Link
                    to="/"
                    state="/sell"
                    className={showTabs ? 'tabLink ' : 'tabLink active'}
                    onClick={handleShowTabs}
                  >
                    Sell Textbooks
                  </Link>
                </div>
                <div className="sell-books">
                  <Link to="/item">Recently Viewed</Link>
                </div>
                <div className="items">
                  <div className="searches">
                    <div className="clear-box">
                      <Link to={{}}>Clear Searches</Link>
                    </div>
                  </div>
                </div>
                {/* <div className="other-links">
                  <Link to="/university">University Pages</Link>
                </div> */}
              </div>
              <div className="right">
                <div className="search-country-bar item-search">
                  <div className="search-bar">
                    <div className="search-box">
                      <input
                        type="text"
                        placeholder="Search for ISBN, Title or Author"
                      />
                      <Button>
                        <i className="far fa-search" />
                      </Button>
                    </div>
                  </div>
                  <BookResponsiveNav />
                </div>

                <div className="all-content-block">
                  <div className="universityCSS">
                    <h2>Universities &amp; Collages Pages</h2>

                    <UniversityTiles data={TilesR1} />

                    <UniversityTiles data={TilesR2} />
                    <UniversityTiles data={TilesR3} />

                    <UniversityTiles data={TilesR4} />

                    <UniversityTiles data={TilesR5} />
                    <UniversityTiles data={TilesR6} />
                    <UniversityTiles data={TilesR7} />

                    <UniversityTiles data={TilesR8} />

                    <UniversityTiles data={TilesR9} />
                    {/* 
This row is different from above mentioned Row */}

                    <div className="uniRow uniRowCSS">
                      <div className="uniList">
                        <Image
                          src={require('../../img/uni28.png')}
                          className="img-fluid uniPic"
                          alt="..."
                        />
                        <div className="uniHeading">
                          <div className="in-text">
                            <a href="https://www.cornell.edu/" target="_blank">
                              <h4>Cornell University</h4>
                            </a>
                            <a
                              href="https://en.wikipedia.org/wiki/Cornell_University"
                              target="_blank"
                            >
                              <p>Wiki Page</p>
                            </a>
                          </div>
                          <a
                            href="https://www.facebook.com/Cornell"
                            className="uniFeedback"
                          >
                            Facebook
                            <i className="fab fa-facebook" />
                          </a>
                        </div>
                      </div>
                      <div className="uniList">
                        <Image
                          src={require('../../img/uni29.png')}
                          className="img-fluid uniPic"
                          alt="..."
                        />
                        <div className="uniHeading">
                          <div className="in-text">
                            <a
                              href="https://www.northwestern.edu/"
                              target="_blank"
                            >
                              <h4>Northwestern University</h4>
                            </a>
                            <a
                              href="https://en.wikipedia.org/wiki/Northwestern_University"
                              target="_blank"
                            >
                              <p>Wiki Page</p>
                            </a>
                          </div>
                          <a
                            href="https://www.facebook.com/NorthwesternU"
                            className="uniFeedback"
                            target="_blank"
                          >
                            Facebook
                            <i className="fab fa-facebook" />
                          </a>
                        </div>
                      </div>
                      <div className="uniList">
                        <Image
                          src={require('../../img/uni30.png')}
                          className="img-fluid uniPic"
                          alt="..."
                        />
                        <div className="uniHeading">
                          <div className="in-text">
                            <a href="https://www.virginia.edu/" target="_blank">
                              <h4>University of Virginia</h4>
                            </a>
                            <a
                              href="https://en.wikipedia.org/wiki/University_of_Virginia"
                              target="_blank"
                            >
                              <p>Wiki Page</p>
                            </a>
                          </div>
                          <a
                            href="https://www.facebook.com/UniversityofVirginia/"
                            className="uniFeedback"
                            target="_blank"
                          >
                            Facebook
                            <i className="fab fa-facebook" />
                          </a>
                        </div>
                      </div>
                    </div>
                    <Link to={{}} className="view_">
                      View More
                    </Link>
                  </div>
                </div>
              </div>
            </Col>
          </Col>
        </Row>
        {/* item-main */}
        <Footer />
      </Container>

      <LoginModal showModal={showModal} setShowModal={setShowModal} />
    </>
  );
}

export default University;
