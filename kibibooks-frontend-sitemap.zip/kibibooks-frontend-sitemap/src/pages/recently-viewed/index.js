import React, { useState, useRef, useEffect } from 'react';
import { Button, Image } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTimes, faAngleRight } from '@fortawesome/free-solid-svg-icons';
import { Link, useNavigate } from 'react-router-dom';

import BookCardList from '../../components/recently-viewed/book-card-list';
import Footer from '../../components/footer';
import LoginModal from '../../components/modal/login';
import BookResponsiveNav from '../../components/nav/BookResponsiveNav';
import { getRequest, postRequest } from '../../services/api';
import { apiUrlList } from '../../services/api-url-list';

import './styles.css';

function RecentlyViewed() {
  const navigate = useNavigate();

  const [showModal, setShowModal] = useState(false);
  const [ShowSide, setShowSide] = useState(false);
  const [search, setSearch] = useState('');
  const [currentUser, setCurrentUser] = useState(null);
  const [showLoggedInUserAction, setShowLoggedInUserAction] = useState(false);

  const handleShow = () => setShowModal(true);

  useEffect(() => {
    window.scrollTo(0, 0);

    getRequest(apiUrlList.currentUser, {}, {}, { withCredentials: true }).then(
      (response) => {
        setCurrentUser(response.data);
      }
    );
  }, []);

  function onSubmit(e) {
    e.preventDefault();

    if (search !== '') {
      navigate('/search', {
        state: { search },
      });
    }
  }

  const ref = useRef();
  useOnClickOutside(ref, () => setShowModal(false));

  function useOnClickOutside(ref, handler) {
    useEffect(() => {
      const listener = (event) => {
        if (!ref.current || ref.current.contains(event.target)) {
          return;
        }
        handler(event);
      };
      document.addEventListener('mousedown', listener);
      document.addEventListener('touchstart', listener);
      return () => {
        document.removeEventListener('mousedown', listener);
        document.removeEventListener('touchstart', listener);
      };
    }, [ref, handler]);
  }

  const [recentlyViewedBooks, setRecentlyViewedBooks] = useState(
    JSON.parse(localStorage.getItem('viewedBooks'), '[]')
  );

  function handleDelete(book) {
    const results = recentlyViewedBooks.filter(
      (recentBook) => recentBook.isbn13 !== book.isbn13
    );

    setRecentlyViewedBooks(results);
    localStorage.setItem('viewedBooks', JSON.stringify(results));
  }

  return (
    <>
      <div className="main-body">
        <div className="item-main">
          <div className="item-main-row">
            <div className="mob-menu">
              <div className="header-row">
                <Link to="/" className="sm-logo">
                  <Image
                    src={require('../../img/mobile-logo.png')}
                    className="log-pic img-fluid-"
                    alt="..."
                  />
                </Link>
                <div className="dropdown">
                  <button
                    id="first"
                    type="button"
                    className="tg-btn"
                    data-toggle="dropdown"
                    onClick={() => setShowSide(true)}
                  />
                  <div
                    id="mySide"
                    className="sidebar2-"
                    style={{ display: ShowSide ? 'block' : 'none' }}
                  >
                    <div id="myBtn" className="new2">
                      <div className="texts">
                        <Link
                          to={{}}
                          id="closeBtn"
                          className="closeBtn2"
                          onClick={() => setShowSide(false)}
                        >
                          <FontAwesomeIcon icon={faTimes} />
                        </Link>
                        <div className="left">
                          {currentUser ? (
                            <div className="login-register login-register2 login-register">
                              <div
                                className="dropdown"
                                onClick={() =>
                                  setShowLoggedInUserAction(
                                    !showLoggedInUserAction
                                  )
                                }
                              >
                                <Link
                                  to={{}}
                                  className={
                                    !showLoggedInUserAction
                                      ? 'dropButton anti-btn dropdown-toggle'
                                      : 'dropButton anti-btn dropdown-toggle rotate'
                                  }
                                >
                                  {`Welcome ${currentUser.firstName}`}
                                </Link>
                              </div>

                              <div
                                className="sign-out-btn-drop"
                                style={{
                                  display: showLoggedInUserAction
                                    ? 'block'
                                    : 'none',
                                }}
                              >
                                <Link
                                  to={{}}
                                  onClick={() => {
                                    postRequest(
                                      apiUrlList.logout,
                                      {},
                                      {},
                                      {},
                                      { withCredentials: true }
                                    )
                                      .then(() => {
                                        setCurrentUser(null);
                                      })
                                      .catch(() => {});
                                  }}
                                >
                                  Sign Out
                                </Link>
                                <Link
                                  to={{}}
                                  onClick={() => {
                                    postRequest(
                                      apiUrlList.unRegister,
                                      {},
                                      {},
                                      {},
                                      { withCredentials: true }
                                    )
                                      .then(() => {
                                        setCurrentUser(null);
                                      })
                                      .catch(() => {});
                                  }}
                                >
                                  Unregister
                                </Link>
                              </div>
                            </div>
                          ) : (
                            <div
                              className="login-register"
                              onClick={handleShow}
                            >
                              <Link
                                to={{}}
                                style={{ color: '#fff' }}
                                data-toggle="modal"
                                data-target="#myModal2"
                              >
                                Hello! Sign In
                              </Link>
                            </div>
                          )}
                          <div className="sell-books">
                            <Link to="/" state="/sell">
                              Sell TextBooks
                            </Link>
                          </div>
                          <div className="sell-books sell-books2">
                            <Link to="/recently-viewed" className="item">
                              Recently Viewed
                            </Link>
                          </div>
                          <div className="items">
                            <div className="searches">
                              <div className="search-box search-box2">
                                {recentlyViewedBooks?.map((book, index) => (
                                  <div
                                    key={index}
                                    style={{
                                      display: 'flex',
                                      color: '#a3a8b9',
                                      fontSize: '13px',
                                      fontFamily: 'inherit',
                                      backgroundImage:
                                        'linear-gradient(-270deg, rgb(63, 64, 87) 0%, rgb(32, 33, 37) 100%)',
                                    }}
                                  >
                                    <FontAwesomeIcon
                                      color="#a3a8b9"
                                      icon={faAngleRight}
                                      style={{
                                        marginTop: '3px',
                                        marginRight: '3px',
                                      }}
                                    />
                                    <p
                                      style={{
                                        paddingLeft: '5px',
                                        cursor: 'pointer',
                                      }}
                                      onClick={() => {
                                        navigate(
                                          `/book-details/${book.isbn13}`,
                                          {
                                            replace: true,
                                          }
                                        );
                                      }}
                                    >
                                      {book.title}
                                    </p>
                                    <FontAwesomeIcon
                                      onClick={() => handleDelete(book)}
                                      color="#a3a8b9"
                                      style={{
                                        cursor: 'pointer',
                                        marginTop: '2px',
                                        marginLeft: 'auto',
                                      }}
                                      icon={faTimes}
                                    />
                                  </div>
                                ))}
                              </div>
                              <div className="clear-box">
                                <Link
                                  to={{}}
                                  onClick={() => {
                                    localStorage.removeItem('viewedBooks');
                                    setRecentlyViewedBooks([]);
                                  }}
                                >
                                  Clear Searches
                                </Link>
                              </div>
                            </div>
                          </div>
                          {/* <div className="other-links">
                            <Link to="/university">University Pages</Link>
                          </div> */}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="top-block px-0">
              <div className="left left2">
                <Link to="/" className="cnt-logo">
                  <Image
                    src={require('../../img/logo.png')}
                    className="img-fluid- cnt-lgo"
                    alt="..."
                  />
                </Link>
                <div className="logo-block"></div>
                {currentUser ? (
                  <div className="login-register login-register2 login-register">
                    <div
                      className="dropdown"
                      onClick={() =>
                        setShowLoggedInUserAction(!showLoggedInUserAction)
                      }
                    >
                      <Link
                        to={{}}
                        className={
                          !showLoggedInUserAction
                            ? 'dropButton anti-btn dropdown-toggle'
                            : 'dropButton anti-btn dropdown-toggle rotate'
                        }
                      >
                        {`Welcome ${currentUser.firstName}`}
                      </Link>
                    </div>

                    <div
                      className="sign-out-btn-drop"
                      style={{
                        display: showLoggedInUserAction ? 'block' : 'none',
                      }}
                    >
                      <Link
                        to={{}}
                        onClick={() => {
                          postRequest(
                            apiUrlList.logout,
                            {},
                            {},
                            {},
                            { withCredentials: true }
                          )
                            .then(() => {
                              setCurrentUser(null);
                            })
                            .catch(() => {});
                        }}
                      >
                        Sign Out
                      </Link>
                      <Link
                        to={{}}
                        onClick={() => {
                          postRequest(
                            apiUrlList.unRegister,
                            {},
                            {},
                            {},
                            { withCredentials: true }
                          )
                            .then(() => {
                              setCurrentUser(null);
                            })
                            .catch(() => {});
                        }}
                      >
                        Unregister
                      </Link>
                    </div>
                  </div>
                ) : (
                  <div className="login-register" onClick={handleShow}>
                    <Link
                      to={{}}
                      style={{ color: '#fff' }}
                      data-toggle="modal"
                      data-target="#myModal2"
                    >
                      Hello! Sign In
                    </Link>
                  </div>
                )}

                <div className="sell-books">
                  <Link to="/" state="/sell">
                    Sell Textbooks
                  </Link>
                </div>
                <div className="sell-books sell-books2">
                  <Link to="/recently-viewed" className="item">
                    Recently Viewed
                  </Link>
                </div>
                <div className="items">
                  <div className="searches">
                    <div className="search-box search-box2">
                      {recentlyViewedBooks?.map((book, index) => (
                        <div
                          key={index}
                          style={{
                            display: 'flex',
                            color: '#a3a8b9',
                            fontSize: '13px',
                            fontFamily: 'inherit',
                            backgroundImage:
                              'linear-gradient(-270deg, rgb(63, 64, 87) 0%, rgb(32, 33, 37) 100%)',
                          }}
                        >
                          <FontAwesomeIcon
                            color="#a3a8b9"
                            icon={faAngleRight}
                            style={{ marginTop: '3px', marginRight: '3px' }}
                          />
                          <p
                            style={{ paddingLeft: '5px', cursor: 'pointer' }}
                            onClick={() => {
                              navigate(`/book-details/${book.isbn13}`, {
                                replace: true,
                              });
                            }}
                          >
                            {book.title}
                          </p>
                          <FontAwesomeIcon
                            onClick={() => handleDelete(book)}
                            color="#a3a8b9"
                            style={{
                              cursor: 'pointer',
                              marginTop: '2px',
                              marginLeft: 'auto',
                            }}
                            icon={faTimes}
                          />
                        </div>
                      ))}
                    </div>

                    <div className="clear-box">
                      <Link
                        to={{}}
                        onClick={() => {
                          localStorage.removeItem('viewedBooks');
                          setRecentlyViewedBooks([]);
                        }}
                      >
                        Clear Searches
                      </Link>
                    </div>
                  </div>
                </div>
                {/* <div className="other-links">
                  <Link to="/university">University Pages</Link>
                </div> */}
              </div>
              <div className="right">
                <div className="search-country-bar item-search">
                  <div className="search-bar">
                    <div className="search-box">
                      <form onSubmit={onSubmit}>
                        <input
                          type="text"
                          placeholder="Search for ISBN, Title or Author"
                          onChange={(e) => setSearch(e.target.value)}
                        />
                        <Button
                          onClick={() => {
                            if (search !== '') {
                              navigate('/search', {
                                state: { search },
                              });
                            }
                          }}
                        >
                          <i className="far fa-search" />
                        </Button>
                      </form>
                    </div>
                  </div>
                  <BookResponsiveNav />
                </div>
                <div className="all-content-block">
                  <BookCardList books={recentlyViewedBooks || []} />
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </div>

      <LoginModal showModal={showModal} setShowModal={setShowModal} />
    </>
  );
}

export default RecentlyViewed;
