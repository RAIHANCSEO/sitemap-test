export const apiUrlList = {
  currentUser: '/api/users/current',
  sendReview: '/api/users/send-review',
  sendPartnerMessage: '/api/users/partner',
  sendContactUsMessage: '/api/users/contact',
  bookList: '/api/books',
  bookDetails: '/api/books/{isbn13}',
  bookSellPrices: '/api/books/sell-prices/{isbn13}',
  googleLogin: '/api/auth/google',
  facebookLogin: '/api/auth/facebook',
  logout: '/api/auth/logout',
  unRegister: '/api/auth/un-register',
};
