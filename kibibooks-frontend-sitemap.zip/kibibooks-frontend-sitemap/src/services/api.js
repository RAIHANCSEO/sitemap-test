import axios from 'axios';

export const apiBaseUrl = 'https://api.kibibooks.com';

export const postRequest = (
  url,
  params = {},
  query = {},
  data = {},
  options = {}
) => {
  url = apiBaseUrl + url;

  return axios.post(url, data, { ...options });
};

export const getRequest = (url, params = {}, query = {}, options = {}) => {
  url = buildUrl(url, params);

  return axios.get(url, { params: query, ...options });
};

function buildUrl(endpointUrl, params) {
  let url = endpointUrl;

  Object.keys(params).forEach((key) => {
    url = url.replace(`{${key}}`, params[key] || '');
  });

  return apiBaseUrl + url;
}
