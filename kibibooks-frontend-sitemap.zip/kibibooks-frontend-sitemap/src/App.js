import './App.css';
import Home from './pages/home';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import RecentlyViewed from './pages/recently-viewed';
import AboutUs from './pages/about-us';
import BookDetails from './pages/book-details/index';
import Contact from './pages/contact';
import Cookies from './pages/cookies';
import Help from './pages/help';
import Partner from './pages/partners';
import Privacy from './pages/privacy';
import Search from './pages/search';
import Terms from './pages/terms';
import Disclaimer from './pages/disclaimer';
import './css/book.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/recently-viewed" element={<RecentlyViewed />} />
        <Route path="/about-us" element={<AboutUs />} />
        <Route path="/book-details/:isbn13" element={<BookDetails />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/cookies" element={<Cookies />} />
        <Route path="/help" element={<Help />} />
        <Route path="/partner" element={<Partner />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/search" element={<Search />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/disclaimer" element={<Disclaimer />} />
      </Routes>
    </Router>
  );
}

export default App;
