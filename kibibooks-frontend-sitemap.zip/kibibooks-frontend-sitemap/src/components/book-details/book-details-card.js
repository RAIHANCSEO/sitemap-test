import React, { useState } from 'react';
import { Image } from 'react-bootstrap';
import ReactStars from 'react-rating-stars-component';
import h2p from 'html2plaintext';

import Sell from '../modal/sell';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronRight } from '@fortawesome/free-solid-svg-icons';
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';

function BookDetailsCard({ bookDetails, bestPrices }) {
  const [showText, setShowText] = useState(false);
  const [showSellModal, setShowModal] = useState(false);

  const handleClose = () => setShowModal(false);
  const handleShow = () => setShowModal(true);

  return (
    <>
      <div className="all-content-top">
        <div className="poster-box">
          <div className="mob-txt">
            <h4>{bookDetails.authors.join(' and ')}</h4>
            <h1>
              {bookDetails.title}
              <p>
                <strong>ISBN-10:</strong> {bookDetails.isbn}
                <strong> ISBN-13:</strong> {bookDetails.isbn13}
              </p>
            </h1>
            <ReactStars
              count={5}
              size={24}
              isHalf={true}
              emptyIcon={<i className="far fa-star"></i>}
              halfIcon={<i className="fa fa-star-half-alt"></i>}
              fullIcon={<i className="fa fa-star"></i>}
              activeColor="#ffd700"
              value={0}
              edit={false}
            />
          </div>
          <Image
            src={bookDetails.image}
            alt="Coming Soon"
            style={{ height: '170px' }}
            onError={({ currentTarget }) => {
              currentTarget.onerror = null;
              currentTarget.src = '/coming-soon.png';
            }}
          />
          <Link to={{}} className="sell_it" onClick={handleShow}>
            {'Sell It'}
          </Link>
          <div className="mob-version">
            <ul>
              <li className="one">
                <strong>List Price:</strong>{' '}
                <span>
                  {bookDetails.msrp ? `$${Math.floor(bookDetails.msrp)}` : '-'}
                  <sup>
                    {bookDetails.msrp
                      ? Math.round(
                          (bookDetails.msrp - Math.floor(bookDetails.msrp)) *
                            100
                        ).toLocaleString('en-US', {
                          minimumIntegerDigits: 2,
                          useGrouping: false,
                        })
                      : '-'}
                  </sup>
                </span>
              </li>
              <li>
                <strong>Publisher:</strong> {bookDetails.publisher}
              </li>
              <li>
                <strong>Format:</strong> {bookDetails.binding}
              </li>
            </ul>
            <div className="about-section about-section2">
              <p>
                {showText
                  ? h2p(bookDetails.synopsis)
                  : `${h2p(bookDetails.synopsis).substring(0, 300)}${
                      h2p(bookDetails.synopsis).length > 300 ? '...' : ''
                    }`}
              </p>
              <button
                id="btnMoreLess2"
                className="ls"
                type="button"
                onClick={() => setShowText(true)}
                style={{ display: !showText ? 'block' : 'none' }}
              >
                <span id="lblText2">Show More</span>
                &nbsp;
                <FontAwesomeIcon icon={faChevronRight} />
              </button>

              <button
                id="btnMoreLess2"
                className="ls"
                type="button"
                onClick={() => setShowText(false)}
                style={{ display: showText ? 'block' : 'none' }}
              >
                <span id="lblText2">Show less</span>
                &nbsp;
                <FontAwesomeIcon icon={faChevronLeft} />
              </button>
            </div>
          </div>
          <span className="show-star d-flex justify-content-center">
            {' '}
            <ReactStars
              count={5}
              size={24}
              isHalf={true}
              emptyIcon={<i className="far fa-star"></i>}
              halfIcon={<i className="fa fa-star-half-alt"></i>}
              fullIcon={<i className="fa fa-star"></i>}
              activeColor="#ffd700"
              value={0}
              className="star-"
              edit={false}
            />
          </span>
        </div>
        <div className="movie-desc">
          <div className="desk-txt">
            <h1>{bookDetails.title}</h1>
            <h4>{bookDetails.authors.join(' and ')}</h4>
          </div>
          <div className="list-items">
            <ul>
              <li>
                <strong>List Price:</strong>{' '}
                <span>
                  {bookDetails.msrp ? `$${Math.floor(bookDetails.msrp)}` : '-'}
                  <sup>
                    {bookDetails.msrp
                      ? Math.round(
                          (bookDetails.msrp - Math.floor(bookDetails.msrp)) *
                            100
                        ).toLocaleString('en-US', {
                          minimumIntegerDigits: 2,
                          useGrouping: false,
                        })
                      : '-'}
                  </sup>
                </span>
              </li>
              <li>
                <strong>ISBN-10: </strong> {bookDetails.isbn}
              </li>
              <li>
                <strong>ISBN-13: </strong> {bookDetails.isbn13}
              </li>
            </ul>
            <ul>
              <li>
                <strong>Publisher: </strong> {bookDetails.publisher}
              </li>
              <li>
                <strong>Format: </strong>
                {bookDetails.binding}
              </li>
            </ul>
          </div>
          <div className="about-section">
            <p>{bookDetails.desc}</p>
            <p>
              {showText
                ? h2p(bookDetails.synopsis)
                : `${h2p(bookDetails.synopsis).substring(0, 300)}${
                    h2p(bookDetails.synopsis).length > 300 ? '...' : ''
                  }`}
            </p>
            <button
              id="btnMoreLess"
              className="ls"
              type="button"
              onClick={() => setShowText(true)}
              style={{ display: !showText ? 'block' : 'none' }}
            >
              <span id="lblText">Show More</span>
              &nbsp; <FontAwesomeIcon icon={faChevronRight} />
            </button>

            <button
              id="btnMoreLess2"
              className="ls"
              type="button"
              onClick={() => setShowText(false)}
              style={{ display: showText ? 'block' : 'none' }}
            >
              <span id="lblText2">Show less</span>
              &nbsp; <FontAwesomeIcon icon={faChevronLeft} />
            </button>
          </div>
        </div>
        <div className="best-prices-section">
          <h2>Best Prices</h2>
          <div className="price-list">
            {bestPrices
              .concat(new Array(7 - bestPrices.length).fill({}))
              .map((priceData, index) => {
                return (
                  <div className="item" key={index}>
                    <p style={{ textTransform: 'capitalize' }}>
                      {priceData.type || '-'}
                    </p>
                    <strong>
                      {priceData.price
                        ? `$${Math.floor(priceData.price)}`
                        : '-'}
                      <sup>
                        {priceData.price
                          ? Math.round(
                              (priceData.price - Math.floor(priceData.price)) *
                                100
                            ).toLocaleString('en-US', {
                              minimumIntegerDigits: 2,
                              useGrouping: false,
                            })
                          : '-'}
                      </sup>
                    </strong>
                    <a href={priceData.bookUrl}>
                      <button
                        className={
                          priceData.type === 'new' ||
                          priceData.type === 'used' ||
                          priceData.type === 'digital'
                            ? 'yellow-small'
                            : priceData.type === 'rental' ||
                              priceData.type === 'digitalRental'
                            ? 'blue-small'
                            : 'disable-btn-bookCard disButton'
                        }
                      >
                        {priceData.type === 'rental' ||
                        priceData.type === 'digitalRental'
                          ? 'Rent It'
                          : 'Buy It'}
                      </button>
                    </a>
                  </div>
                );
              })}
          </div>
        </div>
      </div>

      <Sell
        showModal={showSellModal}
        handleClose={handleClose}
        bookDetails={bookDetails}
      />
    </>
  );
}

export default BookDetailsCard;
