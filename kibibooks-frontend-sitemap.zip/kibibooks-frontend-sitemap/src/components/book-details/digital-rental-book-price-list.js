import React from 'react';
import { Row } from 'react-bootstrap';

function DigitalRentalBookPriceList({ prices }) {
  return (
    <>
      <Row className="detail1">
        <ul className="padding_custom">
          <li className="one">Digital Rentals</li>
          <li className="two mobile_version">Coupons</li>
          <li className="three">Price</li>
          <li className="last" />
        </ul>
        {prices
          .concat(new Array(Math.max(6 - prices.length, 0)).fill({}))
          .splice(0, 6)
          .map((data, index) => (
            <ul className="lines" key={index}>
              <li className="one cmn">
                {data.vendor || '-'}
                <span>{data.duration}</span>
              </li>
              {!data.coupon ? (
                <li className="two mobile_version">-</li>
              ) : (
                <li className="two mobile_version">{data.coupon}</li>
              )}

              <li className="three">
                <strong>
                  {data.price ? `$${Math.floor(data.price)}` : '-'}
                  <sup>
                    {data.price
                      ? Math.round(
                          (data.price - Math.floor(data.price)) * 100
                        ).toLocaleString('en-US', {
                          minimumIntegerDigits: 2,
                          useGrouping: false,
                        })
                      : '-'}
                  </sup>
                </strong>
              </li>
              <li className="last">
                <a href={data.bookUrl}>
                  <button
                    className={
                      data.bookUrl
                        ? 'rent-btn-BookCard'
                        : 'rent-btn-BookCard disabledBtnBookCard'
                    }
                  >
                    Rent It
                  </button>
                </a>
              </li>
            </ul>
          ))}
      </Row>
    </>
  );
}

export default DigitalRentalBookPriceList;
