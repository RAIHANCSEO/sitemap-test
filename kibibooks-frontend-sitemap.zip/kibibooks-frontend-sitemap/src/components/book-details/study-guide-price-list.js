import React from 'react';
import { Row, Image } from 'react-bootstrap';

function StudyGuidePriceList({ audioBookPrices, studyGuidePrices }) {
  return (
    <>
      <Row className="detail1">
        <h4 style={{ display: 'none' }}>Other Material</h4>
        <ul className="padding_custom">
          <li className="one">Study Guides</li>
          <li className="two mobile_version">Coupons</li>
          <li className="three">Price</li>
          <li className="last" />
        </ul>
        {studyGuidePrices
          .concat(new Array(Math.max(2 - studyGuidePrices.length, 0)).fill({}))
          .splice(0, 2)
          .map((data, index) => (
            <ul className="lines" key={index}>
              <li className="one cmn">
                {data.vendor || '-'}
                <span>{data.duration}</span>
              </li>
              {!data.coupon ? (
                <li className="two mobile_version">-</li>
              ) : (
                <li className="two mobile_version">{data.coupon}</li>
              )}

              <li className="three">
                <strong>
                  {data.price ? `$${Math.floor(data.price)}` : '-'}
                  <sup>
                    {data.price
                      ? Math.round(
                          (data.price - Math.floor(data.price)) * 100
                        ).toLocaleString('en-US', {
                          minimumIntegerDigits: 2,
                          useGrouping: false,
                        })
                      : '-'}
                  </sup>
                </strong>
              </li>
              <li className="last">
                <a href={data.bookUrl}>
                  <button
                    className={
                      data.bookUrl
                        ? 'buy-btn-BookCard'
                        : 'buy-btn-BookCard disabledBtnBookCard'
                    }
                  >
                    Buy It
                  </button>
                </a>
              </li>
            </ul>
          ))}
        <ul className="padding_custom padding_custom_1">
          <li className="one">Audio</li>
          <li className="two mobile_version">Coupons</li>
          <li className="three">Price</li>
          <li className="last" />
        </ul>
        <h4 className="new" style={{ display: 'none' }}>
          Digital/Rental
        </h4>
        {audioBookPrices
          .concat(new Array(Math.max(3 - audioBookPrices.length, 0)).fill({}))
          .splice(0, 3)
          .map((data, index) => (
            <ul className="lines" key={index}>
              <li className="one">
                {data.vendor || '-'}
                <span>{data.duration}</span>
              </li>

              {!data.coupon ? (
                <li className="two mobile_version">-</li>
              ) : (
                <li className="two">
                  <Image
                    src="../img/coupon.png"
                    className="img-fluid coupon"
                    alt="..."
                  />
                </li>
              )}

              <li className="three">
                <strong>
                  {data.price ? `$${Math.floor(data.price)}` : '-'}
                  <sup>
                    {data.price
                      ? Math.round(
                          (data.price - Math.floor(data.price)) * 100
                        ).toLocaleString('en-US', {
                          minimumIntegerDigits: 2,
                          useGrouping: false,
                        })
                      : '-'}
                  </sup>
                </strong>
              </li>
              <li className="last">
                <a href={data.bookUrl}>
                  <button
                    className={
                      data.bookUrl
                        ? 'buy-btn-BookCard'
                        : 'buy-btn-BookCard disabledBtnBookCard'
                    }
                  >
                    Buy It
                  </button>
                </a>
              </li>
            </ul>
          ))}
      </Row>
    </>
  );
}

export default StudyGuidePriceList;
