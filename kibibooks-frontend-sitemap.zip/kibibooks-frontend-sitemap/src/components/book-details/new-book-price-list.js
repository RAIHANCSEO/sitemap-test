import React from 'react';
import { Row } from 'react-bootstrap';

function NewBookPriceList({ prices }) {
  return (
    <>
      <Row className="detail1">
        <ul className="padding_custom">
          <li className="one">New</li>
          <li className="two mobile_version">Coupons</li>
          <li className="three">Price</li>
          <li className="last" />
        </ul>

        {prices
          .concat(new Array(Math.max(6 - prices.length, 0)).fill({}))
          .splice(0, 6)
          .map((price, index) => (
            <ul className="lines" key={index}>
              <li className="one">{price.vendor || '-'}</li>
              {!price.coupon ? (
                <li className="two mobile_version">-</li>
              ) : (
                <li className="two mobile_version">{price.coupon}</li>
              )}

              <li className="three">
                <strong>
                  {price.price ? `$${Math.floor(price.price)}` : '-'}
                  <sup>
                    {price.price
                      ? Math.round(
                          (price.price - Math.floor(price.price)) * 100
                        ).toLocaleString('en-US', {
                          minimumIntegerDigits: 2,
                          useGrouping: false,
                        })
                      : '-'}
                  </sup>
                </strong>
              </li>
              <li className="last">
                <a href={price.bookUrl}>
                  <button
                    className={
                      price.bookUrl
                        ? 'buy-btn-BookCard'
                        : 'buy-btn-BookCard disabledBtnBookCard'
                    }
                  >
                    Buy It
                  </button>
                </a>
              </li>
            </ul>
          ))}
      </Row>
    </>
  );
}

export default NewBookPriceList;
