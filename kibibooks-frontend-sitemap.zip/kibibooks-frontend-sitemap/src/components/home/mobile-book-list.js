import React from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col } from 'react-bootstrap';
import { Image } from 'react-bootstrap';
import './resBook.css';
import ReactStars from 'react-rating-stars-component';
function MobileBookList({ books }) {
  return (
    <Container fluid className="px-0 perched perched3">
      <Row>
        <Col className="perched-grid">
          <h3>Most Purchased</h3>
        </Col>
      </Row>
      {books &&
        books.map((book, index) => (
          <div to={book.link ? book.link : ''} key={index}>
            <Col className="book1">
              <Link
                to={{
                  pathname: `/book-details/${book.isbn13}`,
                }}
              >
                <h3>
                  {book.title.substring(0, 60)}
                  {book.title.length > 60 ? '...' : ''}
                </h3>
                <h4>{`by ${book.authors.join(' and ')}`}</h4>
              </Link>
              <div className="book1-row">
                <Link
                  to={{
                    pathname: `/book-details/${book.isbn13}`,
                    prefetch: 'false',
                  }}
                >
                  <Image
                    src={book.image || './coming-soon.png'}
                    className="img-fluid poster_pic"
                    alt="Coming Soon"
                    style={{ height: '170px' }}
                    onError={({ currentTarget }) => {
                      currentTarget.onerror = null;
                      currentTarget.src = './coming-soon.png';
                    }}
                  />
                </Link>
                <div className="book1-right">
                  <p>{book.binding}</p>
                  <p>{book.format}</p>
                  <p className="last">{book.seller}</p>
                  <h4>
                    {book.msrp ? `$${Math.floor(book.msrp)}` : '-'}
                    <sup>
                      {book.msrp
                        ? Math.round(
                            (book.msrp - Math.floor(book.msrp)) * 100
                          ).toLocaleString('en-US', {
                            minimumIntegerDigits: 2,
                            useGrouping: false,
                          })
                        : '-'}
                    </sup>
                  </h4>
                  <div className="margin" />
                  <ReactStars
                    count={5}
                    size={24}
                    isHalf={true}
                    emptyIcon={<i className="far fa-star"></i>}
                    halfIcon={<i className="fa fa-star-half-alt"></i>}
                    fullIcon={<i className="fa fa-star"></i>}
                    activeColor="#ffd700"
                    value={0}
                    edit={false}
                  />
                </div>
              </div>
            </Col>
          </div>
        ))}
    </Container>
  );
}

export default MobileBookList;
