import React from 'react';
import ReactStars from 'react-rating-stars-component';
import { Link } from 'react-router-dom';
import { Image } from 'react-bootstrap';

import './bookList.css';

function BookList({ books }) {
  return (
    <div className="perched">
      <div className="perched-grid">
        <h3>Most Purchased</h3>
        <div className="perched-row perched-row2">
          {books?.map((book, index) => (
            <div className="perched1" key={index}>
              <Link
                to={{
                  pathname: `/book-details/${book.isbn13}`,
                  prefetch: 'false',
                }}
              >
                <Image
                  src={book.image || './coming-soon.png'}
                  className="perch-pic img-fluid"
                  style={{ height: '230px', width: '185px' }}
                  alt="Coming Soon"
                  onError={({ currentTarget }) => {
                    currentTarget.onerror = null;
                    currentTarget.src = './coming-soon.png';
                  }}
                />
              </Link>
              <h4>
                {book.msrp ? `$${Math.floor(book.msrp)}` : '-'}
                <sup>
                  {book.msrp
                    ? Math.round(
                        (book.msrp - Math.floor(book.msrp)) * 100
                      ).toLocaleString('en-US', {
                        minimumIntegerDigits: 2,
                        useGrouping: false,
                      })
                    : '-'}
                </sup>
              </h4>
              <div className="margin" />
              <Link
                to={{
                  pathname: `/book-details/${book.isbn13}`,
                  prefetch: 'false',
                }}
              >
                <ul style={{ height: '80px' }}>
                  <li>
                    {book.title.substring(0, 60)}
                    {book.title.length > 60 ? '...' : ''}
                  </li>

                  <li className="last">
                    by {book.authors.join(' and ').substring(0, 25)}
                    {book.authors.join(' and ').length > 25 ? '...' : ''}
                  </li>
                </ul>
              </Link>
              <ReactStars
                count={5}
                size={24}
                isHalf={true}
                emptyIcon={<i className="far fa-star"></i>}
                halfIcon={<i className="fa fa-star-half-alt"></i>}
                fullIcon={<i className="fa fa-star"></i>}
                activeColor="#ffd700"
                value={0}
                edit={false}
                style={{ marginLeft: '-3px' }}
              />
              <p>{book.binding}</p>
              <p>{book.format}</p>
              <p className="last">{book.seller}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default BookList;
