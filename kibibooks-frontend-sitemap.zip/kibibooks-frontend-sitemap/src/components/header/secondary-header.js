import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Container, Col, Image } from 'react-bootstrap';

import LoginModal from '../modal/login';
import { getRequest, postRequest } from '../../services/api';
import { apiUrlList } from '../../services/api-url-list';

export default function SecondaryHeader({ title = '' }) {
  const [showModal, setShowModal] = useState(false);
  const [showDropdown, setShowDropDown] = useState(false);
  const [viewedBooks, setViewedBooks] = useState([]);
  const [currentUser, setCurrentUser] = useState(false);
  const [showLoggedInUserAction, setShowLoggedInUserAction] = useState(false);

  const handleShow = () => setShowModal(true);

  useEffect(() => {
    setViewedBooks(JSON.parse(localStorage.getItem('viewedBooks') || '[]'));

    getRequest(apiUrlList.currentUser, {}, {}, { withCredentials: true }).then(
      (response) => {
        setCurrentUser(response.data);
      }
    );
  }, []);

  const ref = useRef();
  const userRef = useRef();

  useOnClickOutside(userRef, () => setShowLoggedInUserAction(false));
  useOnClickOutside(ref, () => setShowDropDown(false));

  function useOnClickOutside(ref, handler) {
    useEffect(() => {
      const listener = (event) => {
        if (!ref.current || ref.current.contains(event.target)) {
          return;
        }
        handler(event);
      };
      document.addEventListener('mousedown', listener);
      document.addEventListener('touchstart', listener);
      return () => {
        document.removeEventListener('mousedown', listener);
        document.removeEventListener('touchstart', listener);
      };
    }, [ref, handler]);
  }

  return (
    <Container fluid className="px-0" style={{ overflowX: 'hidden' }}>
      <Col className="px-0 fixedUp">
        <Col className="cont-header">
          <Col className="cont-header-row">
            <Link to="/" className="cnt-logo">
              <Image
                src={require('../../img/logo.png')}
                className="img-fluid cnt-lgo"
                alt="..."
              />
            </Link>
            <h2>{title}</h2>
            <Col className="cont-header-right">
              <ul>
                <li>
                  {currentUser ? (
                    <div className="customMenuDropDown" ref={userRef}>
                      <Link
                        to={{}}
                        onClick={() =>
                          setShowLoggedInUserAction(!showLoggedInUserAction)
                        }
                        className="dropButton anti-btn"
                        style={{ color: '#fff' }}
                      >
                        {`Welcome ${currentUser.firstName}`}
                      </Link>

                      <div
                        id="userOption"
                        className="dropdown-content"
                        style={{
                          display: showLoggedInUserAction
                            ? showLoggedInUserAction
                            : 'none',
                          marginTop: 'auto',
                          marginRight: '12px',
                        }}
                      >
                        <span className="dropButton one"></span>

                        <Link
                          to={{}}
                          onClick={() => {
                            postRequest(
                              apiUrlList.logout,
                              {},
                              {},
                              {},
                              { withCredentials: true }
                            )
                              .then(() => {
                                setCurrentUser(null);
                              })
                              .catch(() => {});
                          }}
                        >
                          <i className="fas fa-chevron-right" />
                          <span
                            onClick={() => setShowLoggedInUserAction(false)}
                          >
                            Sign Out
                          </span>
                        </Link>

                        <Link
                          to={{}}
                          onClick={() => {
                            postRequest(
                              apiUrlList.unRegister,
                              {},
                              {},
                              {},
                              { withCredentials: true }
                            )
                              .then(() => {
                                setCurrentUser(null);
                              })
                              .catch(() => {});
                          }}
                        >
                          <i className="fas fa-chevron-right" />
                          <span
                            onClick={() => setShowLoggedInUserAction(false)}
                          >
                            Unregister
                          </span>
                        </Link>
                      </div>
                    </div>
                  ) : (
                    <div className="login-register" onClick={handleShow}>
                      <Link
                        to={{}}
                        style={{ color: '#fff' }}
                        data-toggle="modal"
                        data-target="#myModal2"
                      >
                        Hello! Sign In
                      </Link>
                    </div>
                  )}
                </li>
                <li className="mid">|</li>

                <li className="last">
                  <div className="dropdown">
                    <Link
                      to={{}}
                      onClick={() => setShowDropDown(!showDropdown)}
                      className="dropCustomButton1 one"
                    >
                      All
                    </Link>

                    <div
                      id="myDropdown"
                      className="dropdown-content"
                      style={{
                        display: showDropdown ? showDropdown : 'none',
                      }}
                      ref={ref}
                    >
                      <Link to="/" state="/sell">
                        <i className="fas fa-chevron-right" /> Sell your
                        Textbooks
                      </Link>

                      <Link
                        to="/recently-viewed"
                        className={viewedBooks.length ? '' : 'deactive'}
                      >
                        <i className="fas fa-chevron-right" /> Recently Viewed
                      </Link>
                    </div>
                  </div>
                </li>
              </ul>
            </Col>
          </Col>
        </Col>
      </Col>

      <LoginModal showModal={showModal} setShowModal={setShowModal} />
    </Container>
  );
}
