import React from 'react';
import { Link } from 'react-router-dom';
import { Image } from 'react-bootstrap';
import '../../pages/recently-viewed/styles.css';
import ReactStars from 'react-rating-stars-component';
import './styles.css';

function BookCardList({ books }) {
  return (
    <>
      {books.length
        ? books.map((book, index) => (
            <div key={index} className="edition">
              <div className="edition-row">
                <div className="edition-left-">
                  <div className="mobile-version-1">
                    <h3>
                      {book.title}
                      <span />
                    </h3>
                    <h4>{`by ${book.authors}`}</h4>
                  </div>
                  <div className="post-">
                    <Image
                      src={book.image || '/coming-soon.png'}
                      style={{ maxHeight: '170px' }}
                      className="poster-pic- img-fluid-"
                      onError={({ currentTarget }) => {
                        currentTarget.onerror = null;
                        currentTarget.src = '/coming-soon.png';
                      }}
                    />
                  </div>
                  <Link to={{}} className="star- d-flex justify-content-center">
                    <ReactStars
                      count={5}
                      size={24}
                      isHalf={true}
                      emptyIcon={<i className="far fa-star"></i>}
                      halfIcon={<i className="fa fa-star-half-alt"></i>}
                      fullIcon={<i className="fa fa-star"></i>}
                      value={0}
                      edit={false}
                      className="str img-fluid-"
                    />
                  </Link>
                  <Link to={`/book-details/${book.isbn13}`} className="view-">
                    View Details
                  </Link>
                </div>
                <div className="edition-right-">
                  <div className="dsc-version">
                    <h3>
                      {book.title}
                      <span />
                    </h3>
                    <h4>{`by ${book.authors}`}</h4>
                  </div>
                  <div className="edition-box-">
                    <ul>
                      <li>New</li>
                      <li>Used</li>
                      <li>Digital</li>
                      <li>Rentals</li>
                      <li>Digital Rentals</li>
                      <li className="last-">Study Guides</li>
                    </ul>
                    <div />
                    <div className="bdr"></div>
                    <div className="seller-">
                      <div className="seller1">
                        <h5>
                          {book.bestPrices[0].vendor || '-'}
                          <span>
                            {book.bestPrices[0].price
                              ? `$${Math.floor(book.bestPrices[0].price)}`
                              : '-'}
                            <sup>
                              {book.bestPrices[0].price
                                ? Math.round(
                                    (book.bestPrices[0].price -
                                      Math.floor(book.bestPrices[0].price)) *
                                      100
                                  ).toLocaleString('en-US', {
                                    minimumIntegerDigits: 2,
                                    useGrouping: false,
                                  })
                                : '-'}
                            </sup>
                          </span>
                        </h5>
                        <a href={book.bestPrices[0].bookUrl}>
                          <button
                            className={
                              book.bestPrices[0].price ? 'buy' : 'buy grey'
                            }
                          >
                            Buy It
                          </button>
                        </a>
                      </div>
                      <div className="seller1">
                        <h5>
                          {book.bestPrices[1].vendor || '-'}
                          <span>
                            {book.bestPrices[1].price
                              ? `$${Math.floor(book.bestPrices[1].price)}`
                              : '-'}
                            <sup>
                              {book.bestPrices[1].price
                                ? Math.round(
                                    (book.bestPrices[1].price -
                                      Math.floor(book.bestPrices[1].price)) *
                                      100
                                  ).toLocaleString('en-US', {
                                    minimumIntegerDigits: 2,
                                    useGrouping: false,
                                  })
                                : '-'}
                            </sup>
                          </span>
                        </h5>
                        <a href={book.bestPrices[1].bookUrl}>
                          <button
                            className={
                              book.bestPrices[1].price ? 'buy' : 'buy grey'
                            }
                          >
                            Buy It
                          </button>
                        </a>
                      </div>
                      <div className="seller1">
                        <h5>
                          {book.bestPrices[2].vendor || '-'}
                          <span>
                            {book.bestPrices[2].price
                              ? `$${Math.floor(book.bestPrices[2].price)}`
                              : '-'}
                            <sup>
                              {book.bestPrices[2].price
                                ? Math.round(
                                    (book.bestPrices[2].price -
                                      Math.floor(book.bestPrices[2].price)) *
                                      100
                                  ).toLocaleString('en-US', {
                                    minimumIntegerDigits: 2,
                                    useGrouping: false,
                                  })
                                : '-'}
                            </sup>
                          </span>
                        </h5>
                        <a href={book.bestPrices[2].bookUrl}>
                          <button
                            className={
                              book.bestPrices[2].price ? 'buy' : 'grey buy'
                            }
                          >
                            Buy It
                          </button>
                        </a>
                      </div>
                      <div className="seller1">
                        <h5>
                          {book.bestPrices[3].vendor || '-'}
                          <span>
                            {book.bestPrices[3].price
                              ? `$${Math.floor(book.bestPrices[3].price)}`
                              : '-'}
                            <sup>
                              {book.bestPrices[3].price
                                ? Math.round(
                                    (book.bestPrices[3].price -
                                      Math.floor(book.bestPrices[3].price)) *
                                      100
                                  ).toLocaleString('en-US', {
                                    minimumIntegerDigits: 2,
                                    useGrouping: false,
                                  })
                                : '-'}
                            </sup>
                          </span>
                        </h5>
                        <a href={book.bestPrices[3].bookUrl}>
                          <button
                            className={
                              book.bestPrices[3].price
                                ? 'buy rent'
                                : 'buy rent grey'
                            }
                          >
                            Rent It
                          </button>
                        </a>
                      </div>

                      <div className="seller1">
                        <h5>
                          {book.bestPrices[4].vendor || '-'}
                          <span>
                            {book.bestPrices[4].price
                              ? `$${Math.floor(book.bestPrices[4].price)}`
                              : '-'}
                            <sup>
                              {book.bestPrices[4].price
                                ? Math.round(
                                    (book.bestPrices[4].price -
                                      Math.floor(book.bestPrices[4].price)) *
                                      100
                                  ).toLocaleString('en-US', {
                                    minimumIntegerDigits: 2,
                                    useGrouping: false,
                                  })
                                : '-'}
                            </sup>
                          </span>
                        </h5>
                        <a href={book.bestPrices[4].bookUrl}>
                          <button
                            className={
                              book.bestPrices[4].price
                                ? 'buy rent'
                                : 'buy rent grey'
                            }
                          >
                            Rent It
                          </button>
                        </a>
                      </div>
                      <div className="seller1">
                        <h5>
                          {book.bestPrices[5].vendor || '-'}
                          <span>
                            {book.bestPrices[5].price
                              ? `$${Math.floor(book.bestPrices[5].price)}`
                              : '-'}
                            <sup>
                              {book.bestPrices[5].price
                                ? Math.round(
                                    (book.bestPrices[5].price -
                                      Math.floor(book.bestPrices[5].price)) *
                                      100
                                  ).toLocaleString('en-US', {
                                    minimumIntegerDigits: 2,
                                    useGrouping: false,
                                  })
                                : '-'}
                            </sup>
                          </span>
                        </h5>

                        <a href={book.bestPrices[5].bookUrl}>
                          <button
                            className={
                              book.bestPrices[5].price
                                ? 'buy rent'
                                : 'buy rent grey'
                            }
                          >
                            Rent It
                          </button>
                        </a>
                      </div>
                    </div>
                  </div>
                  <div className="mob-edition">
                    <div className="mob-edition-list">
                      <div className="mob-edition-item">
                        <p>
                          New<span>{book.bestPrices[0].vendor || '-'}</span>
                        </p>
                        <strong>
                          {book.bestPrices[0].price
                            ? `$${Math.floor(book.bestPrices[0].price)}`
                            : '-'}
                          <sup>
                            {book.bestPrices[0].price
                              ? Math.round(
                                  (book.bestPrices[0].price -
                                    Math.floor(book.bestPrices[0].price)) *
                                    100
                                ).toLocaleString('en-US', {
                                  minimumIntegerDigits: 2,
                                  useGrouping: false,
                                })
                              : '-'}
                          </sup>
                        </strong>
                        <a href={book.bestPrices[0].bookUrl}>
                          <button
                            className={
                              book.bestPrices[0].price
                                ? 'yellow-small'
                                : 'yellow-small grey'
                            }
                          >
                            Buy It
                          </button>
                        </a>
                      </div>
                      <div className="mob-edition-item">
                        <p>
                          Used<span>{book.bestPrices[1].vendor || '-'}</span>
                        </p>
                        <strong>
                          {book.bestPrices[1].price
                            ? `$${Math.floor(book.bestPrices[1].price)}`
                            : '-'}
                          <sup>
                            {book.bestPrices[1].price
                              ? Math.round(
                                  (book.bestPrices[1].price -
                                    Math.floor(book.bestPrices[1].price)) *
                                    100
                                ).toLocaleString('en-US', {
                                  minimumIntegerDigits: 2,
                                  useGrouping: false,
                                })
                              : '-'}
                          </sup>
                        </strong>
                        <a href={book.bestPrices[1].bookUrl}>
                          <button
                            className={
                              book.bestPrices[1].price
                                ? 'yellow-small'
                                : 'yellow-small grey'
                            }
                          >
                            Buy It
                          </button>
                        </a>
                      </div>
                      <div className="mob-edition-item">
                        <p>
                          Digital
                          <span>{book.bestPrices[2].vendor || '-'}</span>
                        </p>
                        <strong>
                          {book.bestPrices[2].price
                            ? `$${Math.floor(book.bestPrices[2].price)}`
                            : '-'}
                          <sup>
                            {book.bestPrices[2].price
                              ? Math.round(
                                  (book.bestPrices[2].price -
                                    Math.floor(book.bestPrices[2].price)) *
                                    100
                                ).toLocaleString('en-US', {
                                  minimumIntegerDigits: 2,
                                  useGrouping: false,
                                })
                              : '-'}
                          </sup>
                        </strong>
                        <a href={book.bestPrices[2].bookUrl}>
                          <button
                            className={
                              book.bestPrices[2].price
                                ? 'yellow-small'
                                : 'yellow-small grey'
                            }
                          >
                            Buy It
                          </button>
                        </a>
                      </div>
                      <div className="mob-edition-item">
                        <p>
                          Rentals
                          <span>{book.bestPrices[3].vendor || '-'}</span>
                        </p>
                        <strong>
                          {book.bestPrices[3].price
                            ? `$${Math.floor(book.bestPrices[3].price)}`
                            : '-'}
                          <sup>
                            {book.bestPrices[3].price
                              ? Math.round(
                                  (book.bestPrices[3].price -
                                    Math.floor(book.bestPrices[3].price)) *
                                    100
                                ).toLocaleString('en-US', {
                                  minimumIntegerDigits: 2,
                                  useGrouping: false,
                                })
                              : '-'}
                          </sup>
                        </strong>
                        <a href={book.bestPrices[3].bookUrl}>
                          <button
                            className={
                              book.bestPrices[3].price
                                ? 'blue-small'
                                : 'blue-small grey '
                            }
                          >
                            Rent It
                          </button>
                        </a>
                      </div>
                      <div className="mob-edition-item">
                        <p>
                          Digital Rentals
                          <span>{book.bestPrices[4].vendor || '-'}</span>
                        </p>
                        <strong>
                          {book.bestPrices[4].price
                            ? `$${Math.floor(book.bestPrices[4].price)}`
                            : '-'}
                          <sup>
                            {book.bestPrices[4].price
                              ? Math.round(
                                  (book.bestPrices[4].price -
                                    Math.floor(book.bestPrices[4].price)) *
                                    100
                                ).toLocaleString('en-US', {
                                  minimumIntegerDigits: 2,
                                  useGrouping: false,
                                })
                              : '-'}
                          </sup>
                        </strong>
                        <a href={book.bestPrices[4].bookUrl}>
                          <button
                            className={
                              book.bestPrices[4].price
                                ? 'blue-small'
                                : 'blue-small grey'
                            }
                          >
                            Rent It
                          </button>
                        </a>
                      </div>
                      <div className="mob-edition-item">
                        <p>
                          Study Guides
                          <span>{book.bestPrices[5].vendor || '-'}</span>
                        </p>
                        <strong>
                          {book.bestPrices[5].price
                            ? `$${Math.floor(book.bestPrices[5].price)}`
                            : '-'}
                          <sup>
                            {book.bestPrices[5].price
                              ? Math.round(
                                  (book.bestPrices[5].price -
                                    Math.floor(book.bestPrices[5].price)) *
                                    100
                                ).toLocaleString('en-US', {
                                  minimumIntegerDigits: 2,
                                  useGrouping: false,
                                })
                              : '-'}
                          </sup>
                        </strong>
                        <a href={book.bestPrices[5].bookUrl}>
                          <button
                            className={
                              book.bestPrices[5].price
                                ? 'yellow-small'
                                : 'yellow-small grey'
                            }
                          >
                            Buy It
                          </button>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        : null}
    </>
  );
}

export default BookCardList;
