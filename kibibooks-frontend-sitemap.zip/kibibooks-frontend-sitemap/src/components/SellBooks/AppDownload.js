import React from "react";
import { Link } from "react-router-dom";
import { Container, Col, Image } from "react-bootstrap";
import "./AppDownload.css"

function AppDownload() {
  return (
    <Container fluid className="steps1">
      <Col className="stepsRow">
        <Col className="stepsLeft">
          <h2>One Step, many steps</h2>
          <Col className="stepper-box">
            <div className="stepper-box-row">
              <ul>
                <li>Step 1</li>
                <li className="last">Step 2</li>
              </ul>
            </div>
          </Col>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam non
            accumsan nibh, vitae iaculis nisi.{" "}
          </p>
          <p className="last">
            Vestibulum nisl arcu. Suspendisse rhoncus feugiat ante vitae umsan.
            Maecenas sit amet tristique lectus. Ut maximus leo noam vehicula,
            imperdiet tempor urna cursus.{" "}
          </p>
          <Col className="apps">
            <ul>
              <li>
                <Link to={{}}>
                  <Image
                    src={require("../../img/app1.png")}
                    className="img-fluid apPic app1_"
                    alt="..."
                  />
                </Link>
              </li>
              <li className="last">
                <Link to={{}}>
                  <Image
                    src={require("../../img/app2.png")}
                    className="img-fluid apPic app1_"
                    alt="..."
                  />
                </Link>
              </li>
            </ul>
          </Col>
        </Col>
        <Col className="stepsRight">
          <Image
            src={require("../../img/app-right.png")}
            className="img-fluid"
            alt="..."
          />
        </Col>
      </Col>
    </Container>
  );
}
export default AppDownload;
