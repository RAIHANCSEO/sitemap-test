import React, { useState } from "react";
import { Link } from "react-router-dom";
import Rating from "../modal/Rating"
function Footer() {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
   const [feedback, setFeedback] = useState(false);

   const handleFeedbackClose = () => setFeedback(false);
   const handleFeedbackShow = () => setFeedback(true);
  
  return (
    <div className="footer container-fluid">
      <div className="footer-row">
        <div className="footer1">
          <ul>
            <li>
              <Link to="/" className="hdr">
                KibiBooks 2022 ©
              </Link>
            </li>
            <li>
              <Link to="/contact">Contact Us</Link>
            </li>
            <li className="last">
              <Link to={{}}>Follow Us</Link>
            </li>
          </ul>
        </div>
        <div className="footer2">
          <ul>
            <li>
              <Link to={{}}>Download our Apps</Link>
            </li>
            <li>
              <Link to={{}}>IOS apps</Link>
            </li>
            <li className="last">
              <Link to={{}}>Android App</Link>
            </li>
          </ul>
        </div>
        <div className="footer3">
          <ul>
            <li>
              <Link to="/help">Help &amp; Support</Link>
            </li>
            <li className="last">
              <Link
                to={{}}
                data-toggle="modal"
                data-target="#myModal4"
                onClick={handleShow}
              >
                Customer Reviews
              </Link>
            </li>
          </ul>
        </div>
        <div className="footer4">
          <ul>
            <li>
              <Link to="/disclaimer">Disclaimer</Link>
            </li>
            <li>
              <Link to="/terms">Terms of Use</Link>
            </li>
            <li>
              <Link to="/privacy">Privacy Policy</Link>
            </li>
            <li className="last">
              <Link to="/cookies">Cookies Policy</Link>
            </li>
          </ul>
        </div>
      </div>
       <Rating handleClose={handleClose} show={show}
       setFeedback={setFeedback}
       />
    </div>
  );
}
export default Footer;
