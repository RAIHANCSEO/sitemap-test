import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Modal, Container, Button } from 'react-bootstrap';

import { postRequest } from '../../services/api';
import { apiUrlList } from '../../services/api-url-list';

import Feedback from '../modal/feed-back';

import './Footer.css';

const scores = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

function Footer() {
  const [show, setShow] = useState(false);
  const [feedback, setFeedback] = useState(false);
  const [satisfactionScore, setSatisfactionScore] = useState(null);
  const [easinessScore, setEasinessScore] = useState(null);
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const handleFeedbackClose = () => setFeedback(false);
  const handleFeedbackShow = () => setFeedback(true);

  function handleSubmit() {
    setIsLoading(true);

    postRequest(
      apiUrlList.sendReview,
      {},
      {},
      {
        satisfactionScore,
        easinessScore,
        message,
      }
    )
      .then(() => {
        setIsLoading(false);
        handleFeedbackShow();
        handleClose();
      })
      .catch(() => {
        setIsLoading(false);
      });
  }

  return (
    <Container fluid className="footer">
      <Container fluid className="footer-row">
        <div className="footer1">
          <ul>
            <li>
              <Link to="/" className="hdr">
                KibiBooks 2022 ©
              </Link>
            </li>
            <li>
              <Link to="/contact">Contact Us</Link>
            </li>
            <li className="last">
              <a
                href="https://www.facebook.com/KibiBooks/"
                target="_blank"
                rel="noreferrer"
              >
                Follow Us
              </a>
            </li>
          </ul>
        </div>
        <div className="footer2">
          <ul>
            <li>
              <Link to="/about-us">About Us</Link>
            </li>
            <li className="last">
              <Link to="/partner">Partners</Link>
            </li>
          </ul>
        </div>
        <div className="footer3">
          <ul>
            <li>
              <Link to="/help">Help &amp; Support</Link>
            </li>
            <li className="last">
              <Link
                to={{}}
                data-toggle="modal"
                data-target="#myModal4"
                onClick={handleShow}
              >
                Customer Reviews
              </Link>
            </li>
          </ul>
        </div>
        <div className="footer4">
          <ul>
            <li>
              <Link to="/disclaimer">Disclaimer</Link>
            </li>
            <li>
              <Link to="/terms">Terms of Use</Link>
            </li>
            <li>
              <Link to="/privacy">Privacy Policy</Link>
            </li>
            <li className="last">
              <Link to="/cookies">Cookies Policy</Link>
            </li>
          </ul>
        </div>
      </Container>
      <div>
        <Modal show={show} onHide={handleClose}>
          <Modal.Body>
            <div className="modal-body">
              <div className="customer-text">
                <Button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  onClick={handleClose}
                >
                  <i className="far fa-times-circle" />
                </Button>
                <h3>Customer Reviews</h3>
                <div className="custom1">
                  <p>
                    How satisfied are you with the way the information is
                    conveyed?
                  </p>
                  <div className="custom1-row">
                    <ul>
                      {scores.map((score, index) => (
                        <li key={index}>
                          <label className="contain">
                            {score}
                            <input
                              type="radio"
                              name="satisfaction"
                              onChange={(e) => {
                                setSatisfactionScore(score);
                              }}
                            />
                            <span className="checkMark" />
                          </label>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="custom2-row">
                    <ul>
                      <li>Not at all</li>
                      <li className="mid enough">Enough</li>
                      <li className="last veryMuch">Very much</li>
                    </ul>
                  </div>
                </div>
                <div className="custom1 custom11">
                  <p>How easy was it to find what you were looking for?</p>
                  <div className="custom1-row">
                    <ul>
                      {scores.map((score, index) => (
                        <li key={index}>
                          <label className="contain">
                            {score}
                            <input
                              type="radio"
                              name="easiness"
                              onChange={(e) => {
                                setEasinessScore(score);
                              }}
                            />
                            <span className="checkMark" />
                          </label>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="custom2-row">
                    <ul>
                      <li>Not at all</li>
                      <li className="mid enough">Enough</li>
                      <li className="last veryMuch">Very much</li>
                    </ul>
                  </div>
                </div>
                <div className="custom1">
                  <p>What would you suggest we change to better assist you?</p>
                  <form>
                    <textarea
                      className="area customerTextArea"
                      placeholder="500 characters"
                      defaultValue={''}
                      onChange={(e) => {
                        setMessage(e.target.value);
                      }}
                    />
                    <input
                      className="customBtn"
                      type="submit"
                      name="Submit"
                      defaultValue="Submit"
                      disabled={isLoading}
                      onClick={(e) => {
                        e.preventDefault();
                        handleSubmit();
                      }}
                    />
                  </form>
                </div>
              </div>
            </div>
          </Modal.Body>
        </Modal>
      </div>
      <Feedback
        feedback={feedback}
        handleFeedBackClose={handleFeedbackClose}
        handleFeedbackShow={handleFeedbackShow}
      />
    </Container>
  );
}

export default Footer;
