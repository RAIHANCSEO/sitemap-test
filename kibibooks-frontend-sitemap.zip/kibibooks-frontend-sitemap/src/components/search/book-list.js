import React from 'react';
import ReactStars from 'react-rating-stars-component';
import { Link, useNavigate } from 'react-router-dom';
import { Image } from 'react-bootstrap';
import { getRequest } from '../../services/api';
import { apiUrlList } from '../../services/api-url-list';

import '../../pages/search/styles.css';

function BookList({ books, setIsLoading }) {
  const navigate = useNavigate();

  function addToRecentlyViewed(isbn13) {
    setIsLoading(true);

    getRequest(apiUrlList.bookDetails, { isbn13 })
      .then((response) => {
        const responseData = response.data;

        const newBooks = responseData.prices
          .filter((price) => price.type === 'new')
          .sort((a, b) => a.price - b.price);
        const used = responseData.prices
          .filter((price) => price.type === 'used')
          .sort((a, b) => a.price - b.price);
        const rental = responseData.prices
          .filter((price) => price.type === 'rental')
          .sort((a, b) => a.price - b.price);
        const digital = responseData.prices
          .filter((price) => price.type === 'digital')
          .sort((a, b) => a.price - b.price);
        const digitalRental = responseData.prices
          .filter((price) => price.type === 'digitalRental')
          .sort((a, b) => a.price - b.price);
        const studyGuide = responseData.prices
          .filter((price) => price.type === 'studyGuide')
          .sort((a, b) => a.price - b.price);

        let viewedBooks = JSON.parse(
          localStorage.getItem('viewedBooks') || '[]'
        );

        viewedBooks = viewedBooks.filter((book) => book.isbn13 !== isbn13);
        viewedBooks.unshift({
          isbn13,
          title: responseData.title,
          authors: `${responseData.authors.join(' and ')}`,
          image: responseData.image,
          bestPrices: [
            newBooks.length ? newBooks[0] : {},
            used.length ? used[0] : {},
            digital.length ? digital[0] : {},
            rental.length ? rental[0] : {},
            digitalRental.length ? digitalRental[0] : {},
            studyGuide.length ? studyGuide[0] : {},
          ].filter((value) => value !== 0),
        });

        while (viewedBooks.length > 25) {
          viewedBooks.pop();
        }

        localStorage.setItem('viewedBooks', JSON.stringify(viewedBooks));

        setIsLoading(false);

        navigate('/recently-viewed');
      })
      .catch(() => {});
  }

  return (
    <>
      {books?.map((book, index) => (
        <div key={index} className="edition">
          <div className="edition-row">
            <div className="edition-left">
              <div className="mob-texts">
                <h3>{book.title}</h3>
                <h4>{book.authors.join(', ')}</h4>
              </div>
              <div className="edition-flex">
                <div className="post">
                  <Image
                    src={book.image}
                    className="poster-pic img-fluid"
                    alt="Coming Soon"
                    style={{ height: '150px' }}
                    onError={({ currentTarget }) => {
                      currentTarget.onerror = null;
                      currentTarget.src = './coming-soon.png';
                    }}
                  />
                  <div className="post-text">
                    <h4>Coming Soon</h4>
                  </div>
                </div>
                <div className="star- d-flex justify-content-center">
                  <ReactStars
                    count={5}
                    size={24}
                    emptyIcon={<i className="far fa-star"></i>}
                    halfIcon={<i className="fa fa-star-half-alt"></i>}
                    fullIcon={<i className="fa fa-star"></i>}
                    activeColor="#ffd700"
                    value={0}
                    edit={false}
                  />
                </div>
              </div>
              <div className="edition1">
                <h3>{book.title}</h3>
                <h4>{`by ${book.authors.join(', ')}`}</h4>
                <div className="about-left">
                  <div className="about1">
                    <ul>
                      <li>{`Year: ${book.date_published || '-'}`}</li>
                      <li>{`Edition: ${book.edition || '-'}`}</li>
                      <li className="last last2">{`Format: ${
                        book.binding || '-'
                      }`}</li>
                    </ul>
                  </div>
                  <div className="about1">
                    <ul>
                      <li>{`ISBN 10: ${book.isbn || '-'}`}</li>
                      <li>{`ISBN 13: ${book.isbn13 || '-'}`}</li>
                      <li className="last">{`Publisher: ${
                        book.publisher || '-'
                      }`}</li>
                    </ul>
                  </div>
                </div>
                <div className="about-left about-left2">
                  <div className="about1">
                    <ul>
                      <li>{`Year: ${book.date_published || '-'}`}</li>
                      <li>{`Edition: ${book.edition || '-'}`}</li>
                      <li>{`Format: ${book.binding || '-'}`}</li>
                    </ul>
                  </div>
                  <div className="about1">
                    <ul></ul>
                  </div>
                </div>
                <div className="newlines">
                  <ul>
                    <li>{`ISBN 10: ${book.isbn}`}</li>
                    <li>{`ISBN 13: ${book.isbn13}`}</li>
                    <li className="last" style={{ fontWeight: 'normal' }}>
                      {`Publisher: ${book.publisher || '-'}`}
                    </li>
                  </ul>
                </div>
                <div className="buttons">
                  <ul>
                    <li>
                      <Link
                        to={{
                          pathname: `/book-details/${book.isbn13}`,
                        }}
                        className="see-btn"
                      >
                        See All
                      </Link>
                    </li>
                    <li>
                      <button
                        to="/recently-viewed"
                        className="price-btn"
                        style={{ borderWidth: '0px' }}
                        onClick={() => {
                          addToRecentlyViewed(book.isbn13);
                        }}
                      >
                        Best Prices
                      </button>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="edition-right">
              <div className="about">
                <div className="about-row">
                  <div className="about-right">
                    <ul>
                      <li>
                        <Link
                          to={{
                            pathname: `/book-details/${book.isbn13}`,
                          }}
                          className="one"
                        >
                          See All
                        </Link>
                      </li>

                      <li className="last">
                        <button
                          style={{ borderWidth: '0px' }}
                          className="two"
                          onClick={() => {
                            addToRecentlyViewed(book.isbn13);
                          }}
                        >
                          Best Prices
                        </button>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </>
  );
}

export default BookList;
