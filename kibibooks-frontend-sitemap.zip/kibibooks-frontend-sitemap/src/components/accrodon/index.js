import React, { useState } from 'react';
import { Accordion } from 'react-bootstrap';

export default function CustomAccordion({ data }) {
  const [currentActiveKey, setCurrentActiveKey] = useState(null);

  const toggleActiveKey = (key) => {
    setCurrentActiveKey(currentActiveKey === key ? null : key);
  };
  return (
    <div id="accordion">
      <Accordion>
        {data.map((data, index) => {
          return (
            <Accordion.Item key={index} eventKey={index} className="card">
              <Accordion.Header>
                {/* eslint-disable-next-line jsx-a11y/anchor-is-valid */}
                <a
                  className={
                    currentActiveKey === index
                      ? 'card-link_'
                      : 'card-link_ collapsed'
                  }
                  onClick={() => {
                    toggleActiveKey(index);
                  }}
                  data-toggle="collapse"
                  data-target="#demo"
                >
                  <h5 className="">
                    {data.title}
                  </h5>
                </a>
              </Accordion.Header>
              <Accordion.Body>
                <div className="card-body">
                  <div className="card-text">
                    <p>{data.text}</p>
                    <ul style={{ display: data.n1 ? 'block' : 'none' }}>
                      <li>
                        <span>{data.n1}</span>
                        {data.n1t}
                      </li>
                      <li>
                        <span>{data.n2}</span>
                        {data.n2t}
                      </li>
                      <li>
                        <span>{data.n3}</span>
                        {data.n3t}
                      </li>
                      <li className="last">
                        <span>{data.n4}</span>
                        {data.n4t}
                      </li>
                    </ul>
                  </div>
                </div>
              </Accordion.Body>
            </Accordion.Item>
          );
        })}
      </Accordion>
    </div>
  );
}
