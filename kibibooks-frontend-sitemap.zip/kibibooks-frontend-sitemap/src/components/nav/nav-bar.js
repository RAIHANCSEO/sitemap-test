import React, { useEffect, useState, useRef } from 'react';
import { Button } from 'react-bootstrap';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Image } from 'react-bootstrap';

import BookResponsiveNav from './BookResponsiveNav';
import Sell from '../modal/sell';
import LoginModal from '../modal/login';
import { getRequest, postRequest } from '../../services/api';
import { apiUrlList } from '../../services/api-url-list';

import './styles.css';

function NavigationBar() {
  const location = useLocation();
  const navigate = useNavigate();
  const data = location.state;

  const [showSellModal, setShowSellModal] = useState(false);
  const [bookDetails, setBookDetails] = useState(null);
  const [showDropdown, setShowDropDown] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [search, setSearch] = useState('');
  const [selectedTab, setSelectedTab] = useState('buy');
  const [viewedBooks, setViewedBooks] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [showLoggedInUserAction, setShowLoggedInUserAction] = useState(false);

  useEffect(() => {
    if (window.location.pathname === '/rentbooks' || data === '/sell') {
      setSelectedTab('sell');
    }
    setViewedBooks(JSON.parse(localStorage.getItem('viewedBooks') || '[]'));
  }, [data]);

  const handleShow = () => setShowModal(true);

  useEffect(() => {
    window.scrollTo(0, 0);

    getRequest(apiUrlList.currentUser, {}, {}, { withCredentials: true }).then(
      (response) => {
        setCurrentUser(response.data);
      }
    );
  }, []);

  function onSubmit(e) {
    e.preventDefault();

    if (search !== '' && selectedTab === 'buy') {
      navigate('/search', {
        state: { search },
      });
    } else if (search !== '' && selectedTab === 'sell') {
      setShowSellModal(true);

      getRequest(apiUrlList.bookDetails, {
        isbn13: search.replace(/-/g, ''),
      })
        .then((response) => {
          const responseData = response.data;
          setBookDetails(responseData);
        })
        .catch(() => {
          setShowSellModal(false);
        });
    }
  }

  const ref = useRef();
  const userRef = useRef();

  useOnClickOutside(userRef, () => setShowLoggedInUserAction(false));
  useOnClickOutside(ref, () => setShowModal(false));

  function useOnClickOutside(ref, handler) {
    useEffect(() => {
      const listener = (event) => {
        if (!ref.current || ref.current.contains(event.target)) {
          return;
        }
        handler(event);
      };
      document.addEventListener('mousedown', listener);
      document.addEventListener('touchstart', listener);
      return () => {
        document.removeEventListener('mousedown', listener);
        document.removeEventListener('touchstart', listener);
      };
    }, [ref, handler]);
  }

  const ref1 = useRef();
  useOnClickOutside(ref1, () => setShowDropDown(false));

  return (
    <>
      <div className="fixedUp fixed-top">
        <div className="top-header mx-0">
          <div className="header-row">
            <div className="header-left">
              <Link to="/" className="logo">
                <Image
                  src={require('../../img/logo.png')}
                  className="logo-pic img-fluid"
                  alt="..."
                />
              </Link>
              <Link to="/" className="logo2">
                <Image
                  src={require('../../img/logo2.png')}
                  className="logo-pic img-fluid"
                  alt="..."
                />
              </Link>
              <h4>College doesn’t have to be expensive</h4>
            </div>

            <div className="header-right">
              <ul>
                <li>
                  {currentUser ? (
                    <div className="customMenuDropDown" ref={userRef}>
                      <Link
                        to={{}}
                        onClick={() =>
                          setShowLoggedInUserAction(!showLoggedInUserAction)
                        }
                        className="dropButton anti-btn"
                        style={{ color: '#fff' }}
                      >
                        {`Welcome ${currentUser.firstName}`}
                      </Link>

                      <div
                        id="userOption"
                        className="dropdown-content"
                        style={{
                          display: showLoggedInUserAction
                            ? showLoggedInUserAction
                            : 'none',
                          marginTop: 'auto',
                          marginRight: '12px',
                        }}
                      >
                        <span className="dropButton one"></span>

                        <Link
                          to={{}}
                          onClick={() => {
                            postRequest(
                              apiUrlList.logout,
                              {},
                              {},
                              {},
                              { withCredentials: true }
                            )
                              .then(() => {
                                setCurrentUser(null);
                              })
                              .catch(() => {});
                          }}
                        >
                          <i className="fas fa-chevron-right" />
                          <span
                            onClick={() => setShowLoggedInUserAction(false)}
                          >
                            Sign Out
                          </span>
                        </Link>

                        <Link
                          to={{}}
                          onClick={() => {
                            postRequest(
                              apiUrlList.unRegister,
                              {},
                              {},
                              {},
                              { withCredentials: true }
                            )
                              .then(() => {
                                setCurrentUser(null);
                              })
                              .catch(() => {});
                          }}
                        >
                          <i className="fas fa-chevron-right" />
                          <span
                            onClick={() => setShowLoggedInUserAction(false)}
                          >
                            Unregister
                          </span>
                        </Link>
                      </div>
                    </div>
                  ) : (
                    <div className="login-register" onClick={handleShow}>
                      <Link
                        to={{}}
                        style={{ color: '#fff' }}
                        data-toggle="modal"
                        data-target="#myModal2"
                      >
                        Hello! Sign In
                      </Link>
                    </div>
                  )}
                </li>

                <li className="mid">|</li>

                <li className="last">
                  <div className="dropdown customMenuDropDown" ref={ref1}>
                    <Link
                      to={{}}
                      onClick={() => setShowDropDown(!showDropdown)}
                      className="dropButton one"
                    >
                      All
                    </Link>

                    <div
                      id="myDropdown"
                      className="dropdown-content"
                      style={{
                        display: showDropdown ? showDropdown : 'none',
                      }}
                    >
                      <span className="dropButton one"></span>

                      <Link to={{}} onClick={() => setSelectedTab('sell')}>
                        <i className="fas fa-chevron-right" />
                        <span onClick={() => setShowDropDown(false)}>
                          Sell your Textbooks
                        </span>
                      </Link>

                      <Link
                        to="/recently-viewed"
                        className={viewedBooks.length ? '' : 'deactive'}
                      >
                        <i className="fas fa-chevron-right" /> Recently Viewed
                      </Link>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div fluid="true" className="menu mx-0">
          <div className="tab-content">
            <div id="Home">
              <div className="tab-row">
                <div className="tabCustom">
                  <ul className="nav nav-tabs">
                    <li>
                      <Link
                        to={{}}
                        className={
                          selectedTab === 'buy' ? 'tabLink active' : 'tabLink'
                        }
                        onClick={() => setSelectedTab('buy')}
                      >
                        Buy or Rent Textbooks
                      </Link>
                    </li>
                    <li className="middleText">or</li>
                    <li>
                      <Link
                        to={{}}
                        className={
                          selectedTab === 'buy' ? 'tabLink ' : 'tabLink active'
                        }
                        onClick={() => setSelectedTab('sell')}
                      >
                        Sell Textbooks
                      </Link>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="tab-box tab-content">
                <div id="menu" className="enq-box tab-pane active">
                  <h4 className="wld">
                    Find you textbooks at the cheapest prices
                  </h4>
                  <div className="enq-search">
                    <div className="search-country-bar">
                      <div className="search-bar">
                        <div className="search-box">
                          <form onSubmit={onSubmit}>
                            <input
                              type="text"
                              placeholder={
                                selectedTab === 'buy'
                                  ? 'Search by ISBN, Title or Author'
                                  : 'Search by ISBN'
                              }
                              value={search}
                              onChange={(e) => {
                                setSearch(e.target.value);
                              }}
                            />
                            <Button type="submit">
                              <i className="far fa-search" />
                            </Button>
                          </form>
                        </div>
                      </div>
                      <BookResponsiveNav />
                      <div className="numbers">
                        <ul>
                          <li>
                            <a href="/" className="toolTip1">
                              <span className="toolTipText1">
                                An ISBN number is an International Standard Book
                                Number. Essentially, it is a book identifier
                                used by publishers, booksellers, libraries,
                                internet retailers, and other supply chain
                                participants.
                              </span>
                              What is an ISBN number?
                            </a>
                          </li>
                          {/*This is commented out to hide university page information*/}
                          {/* <li class="last">
                            <a href="#" class="toolTip1">
                              <span class="toolTipText1">
                                University Pages is a list of academic
                                institutions webpages, Facebook, and Wikipedia
                                pages. Users can look up any information offered
                                through these pages, as well as look for books
                                being sold by students of that academic
                                institution on their Facebook page.
                              </span>
                              What are the University Pages?
                            </a>
                          </li> */}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <LoginModal showModal={showModal} setShowModal={setShowModal} />

      <Sell
        showModal={showSellModal}
        handleClose={() => setShowSellModal(false)}
        bookDetails={bookDetails}
      />
    </>
  );
}

export default NavigationBar;
