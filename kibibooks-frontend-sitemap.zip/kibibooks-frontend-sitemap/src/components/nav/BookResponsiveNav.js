import React, { useState, useEffect } from 'react';
import { Dropdown, Image } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import './BookResponsiveNav.css';
function BookResponsiveNav() {
  const [img, setImg] = useState('flag.png');
  const handleImage = (img) => {
    setImg(img);
    localStorage.setItem('rememberMe', img);
  };

  useEffect(() => {
    const cu = localStorage.getItem('rememberMe');
    if (cu !== null) {
      setImg(cu);
    }
  }, []);

  return (
    <div className="new-dpn">
      <Dropdown>
        <Dropdown.Toggle
          style={{ background: 'transparent', border: 'none' }}
          id="dropdown-basic"
        >
          <button
            className="button"
            type="button"
            data-toggle="dropdown"
            style={{ border: 'none' }}
          >
            <Image
              src={require(`../../img/${img}`)}
              className="flag img-fluid"
              alt="..."
            />
          </button>
          {/* <Dropdown.Menu>
            <Dropdown.Item>
              <Link to={{}}>
                <Image
                  src={require('../../img/flag.png')}
                  className="img-fluid"
                  alt="..."
                  onClick={() => handleImage('flag.png')}
                />
              </Link>
            </Dropdown.Item>
            <Dropdown.Item>
              <Link to={{}}>
                <Image
                  src={require('../../img/flag1.png')}
                  className="img-fluid"
                  alt="..."
                  onClick={() => handleImage('flag1.png')}
                />
              </Link>
            </Dropdown.Item>
            
            <Dropdown.Item>
              <Link to={{}}>
                <Image
                  src={require('../../img/flag2.png')}
                  className="img-fluid"
                  alt="..."
                  onClick={() => handleImage('flag2.png')}
                />
              </Link>
            </Dropdown.Item>

            <Dropdown.Item>
              <Link to={{}}>
                {' '}
                <Image
                  src={require('../../img/flag4.png')}
                  className="img-fluid"
                  alt="..."
                  onClick={() => handleImage('flag4.png')}
                />
              </Link>
            </Dropdown.Item>

            <Dropdown.Item>
              <Link to={{}}>
                <Image
                  src={require('../../img/flag3.png')}
                  className="img-fluid"
                  alt="..."
                  onClick={() => handleImage('flag3.png')}
                />
              </Link>
            </Dropdown.Item>

            <Dropdown.Item>
              <Link to={{}}>
                <Image
                  src={require('../../img/newFLag.png')}
                  className="img-fluid"
                  alt="..."
                  onClick={() => handleImage('newFLag.png')}
                />
              </Link>
            </Dropdown.Item>
          </Dropdown.Menu> */}
        </Dropdown.Toggle>
      </Dropdown>
    </div>
  );
}

export default BookResponsiveNav;
