import React from "react";
import { Row, Col ,Image} from "react-bootstrap";
import "./UniversityTiles.css";
function UniversityTiles({ data }) {
  return (
    <Row className="uniRow">
      {data &&
        data.map((dat, index) => (
          <Col className="uniList">
            <Image src={dat.img} className="img-fluid uniPic" alt="..." />
            <div className="uniHeading">
              <a href={dat.Link} target="_blank">
                <h4>{dat.title}</h4>
              </a>
              <a href={dat.wiki} target="_blank">
                <p>{dat.wikiTitle}</p>
              </a>
              <a href={dat.fb} className="uniFeedback" target="_blank">
                Facebook
                <i className="fab fa-facebook" />
              </a>
            </div>
          </Col>
            // <Col className="uniList">
            //   <div className="d-flex">
            //     <div className="uniHeading">
            //       <a href={dat.Link} target="_blank">
            //         <h4>{dat.title}</h4>
            //       </a>
            //       <a href={dat.wiki} target="_blank">
            //         <p>{dat.wikiTitle}</p>
            //       </a>
            //     </div>
            //     <Image src={dat.img} className="img-fluid uniPic" alt="..." />
            //   </div>
            //   <div className="d-flex">
            //     <a href={dat.fb} className="uniFeedback" target="_blank">
            //       Facebook
            //       <i className="fab fa-facebook" />
            //     </a>
            //   </div>
            // </Col>
        ))}
    </Row>
  );
}

export default UniversityTiles;
