import React from 'react';
import { Modal } from 'react-bootstrap';
function Feedback({ feedback, handleFeedBackClose }) {
  return (
    <Modal
      show={feedback}
      onHide={handleFeedBackClose}
      animation={true}
      size="lg"
      centered
      backdrop="true"
      onEntered={() => {
        setTimeout(() => {
          handleFeedBackClose();
        }, 3000);
      }}
    >
      <Modal.Body>
        <div className="mod-bdy mod-bdy2">
          <button
            type="button"
            className="close"
            data-dismiss="modal"
            onClick={handleFeedBackClose}
          >
            <i className="far fa-times-circle"></i>
          </button>
          <h3 style={{ padding: '60px 40px 60px 40px' }}>
            Thank you for your feedback!
          </h3>
        </div>
      </Modal.Body>
    </Modal>
  );
}

export default Feedback;
