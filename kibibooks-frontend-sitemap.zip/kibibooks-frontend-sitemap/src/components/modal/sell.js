import React, { useRef, useEffect, useState } from 'react';
import { Modal, Button, Image } from 'react-bootstrap';
import { getRequest } from '../../services/api';
import { apiUrlList } from '../../services/api-url-list';

function Sell({ showModal, handleClose, bookDetails }) {
  const [sellPrices, setSellPrices] = useState([]);

  useEffect(() => {
    if (bookDetails && bookDetails.isbn13) {
      getRequest(apiUrlList.bookSellPrices, { isbn13: bookDetails.isbn13 })
        .then((response) => {
          setSellPrices(response.data.results);
        })
        .catch(() => {});
    }
  }, [bookDetails]);

  const ref = useRef();
  useOnClickOutside(ref, handleClose);

  function useOnClickOutside(ref, handler) {
    useEffect(() => {
      const listener = (event) => {
        if (!ref.current || ref.current.contains(event.target)) {
          return;
        }
        handler(event);
      };
      document.addEventListener('mousedown', listener);
      document.addEventListener('touchstart', listener);
      return () => {
        document.removeEventListener('mousedown', listener);
        document.removeEventListener('touchstart', listener);
      };
    }, [ref, handler]);
  }

  return (
    <Modal show={showModal} onHide={handleClose}>
      <Modal.Body>
        {bookDetails && (
          <div className="modal-body">
            <div className="sell-text" ref={ref}>
              <Button
                type="button"
                className="close"
                data-dismiss="modal"
                onClick={handleClose}
              >
                <i className="far fa-times-circle" />
              </Button>
              <h3>Sell your Textbook</h3>
              <div className="sell-text-flex ">
                <Image
                  src={bookDetails.image || '/coming-soon.png'}
                  style={{ maxHeight: '200px' }}
                  className="img-fluid sl-bk"
                  alt="Coming Soon"
                  onError={({ currentTarget }) => {
                    currentTarget.onerror = null;
                    currentTarget.src = '/coming-soon.png';
                  }}
                />
                <div className="sell-text-right">
                  <h4>
                    {bookDetails.title.substring(0, 58)}
                    {bookDetails.title.length > 58 ? '...' : ''}
                    <br />
                    Edition: {bookDetails.edition || ''}
                  </h4>
                  <p>
                    {`by ${bookDetails.authors.join(' and ').substring(0, 55)}${
                      bookDetails.authors.join(' and ').length > 60 ? '...' : ''
                    }` || '-'}
                  </p>
                  <ul>
                    <li>ISBN 10: {bookDetails.isbn || '-'}</li>
                    <li className="last">
                      ISBN 13: {bookDetails.isbn13 || '-'}
                    </li>
                  </ul>
                </div>
              </div>

              <div className="d-flex flex-sm-row flex-column justify-content-around pt-4">
                {sellPrices
                  .concat(
                    new Array(Math.max(4 - sellPrices.length, 0)).fill({})
                  )
                  .splice(0, 4)
                  .map((price, index) => (
                    <div
                      key={index}
                      className="d-flex flex-sm-column mt-3 mt-md-0 flex-row  justify-content-between align-items-center  modalPrices"
                    >
                      <h6 className="vendorHeading">{price.vendor || '-'}</h6>
                      <div className="d-flex flex-sm-column flex-row align-items-center align-items-center">
                        <h5 className="one cardPrice marginEnd">
                          {price.price ? `$${Math.floor(price.price)}` : '-'}
                          <sup>
                            {price.price
                              ? Math.round(
                                  (price.price - Math.floor(price.price)) * 100
                                ).toLocaleString('en-US', {
                                  minimumIntegerDigits: 2,
                                  useGrouping: false,
                                })
                              : '-'}
                          </sup>
                        </h5>
                        <a href={price.bookUrl}>
                          <button
                            disabled={price.vendor ? false : true}
                            to={{}}
                            className={
                              price.vendor ? 'buy-btn' : 'customDisabledBtn'
                            }
                          >
                            Sell It
                          </button>
                        </a>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}
      </Modal.Body>
    </Modal>
  );
}

export default Sell;
