import { Modal, Button, Image } from 'react-bootstrap';

import { apiBaseUrl } from '../../services/api';
import { apiUrlList } from '../../services/api-url-list';

export default function LoginModal({ showModal, setShowModal }) {
  const handleClose = () => setShowModal(false);

  return (
    <Modal
      show={showModal}
      onHide={handleClose}
      style={{ background: 'transparent' }}
      centered
      backdrop="true"
    >
      <div className="modal-content">
        <div className="modal-body">
          <div className="mod-bdy mod-bdy2">
            <Button
              type="button"
              className="close"
              data-dismiss="modal"
              onClick={handleClose}
            >
              <i className="far fa-times-circle" />
            </Button>
            <h4>
              Hello!
              <br />
              Sign In or Register
            </h4>
            <ul>
              <li>
                <a href={`${apiBaseUrl + apiUrlList.facebookLogin}`}>
                  <button className="fb">
                    <Image
                      src={require('../../img/facebook.png')}
                      className="img-fluid fb"
                      alt="..."
                    />{' '}
                    Sign in with Facebook
                  </button>
                </a>
              </li>
              <li className="midText py-2">or</li>
              <li>
                <a href={`${apiBaseUrl + apiUrlList.googleLogin}`}>
                  <button className="ggl">
                    <Image
                      src={require('../../img/google.png')}
                      className="img-fluid fb"
                      alt="..."
                    />{' '}
                    Sign in with Google
                  </button>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </Modal>
  );
}
