import React from "react";

function BookCard(props) {
  const { price, cents, title, author, currentFormat, formats, sellers } =
    props;
  return (
    <div className="perched1">
      <img src="img/poster1.png" className="perch-pic img-fluid" alt="" />
      <h4>
        <span>$</span>
        {price}
        <span className="nw">{cents}</span>
      </h4>
      <div className="bdr"></div>
      <ul>
        <li>{title}</li>
        <li className="last">{author}</li>
      </ul>
      <img src="img/4.5-star.png" className="img-fluid StarPic" alt="" />
      <p>{currentFormat}</p>
      <p>{formats}</p>
      <p className="last">{sellers}</p>
    </div>
  );
}

export default BookCard;
